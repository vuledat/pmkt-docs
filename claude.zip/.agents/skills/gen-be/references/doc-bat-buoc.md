# Đọc bắt buộc trước khi code — `/gen-be` bước 1

Đọc file này TRƯỚC khi gõ dòng Java đầu tiên. Không đọc lướt.

## Chốt đầu vào — không đoán

1. Không có đường dẫn → hỏi lại, **không đoán**, không tự tìm epic gần nhất.
2. **Chưa có plan BE** (user chỉ đưa PYC): báo user rằng chuẩn là chạy `/plan-be` trước, và hỏi: chạy
   `/plan-be` trước rồi code, hay code thẳng từ PYC. User chọn code thẳng → vẫn phải làm **đủ phần
   đọc bắt buộc + khảo sát có bằng chứng của `/plan-be`** trước khi code, và ghi kết quả vào
   `IMPLEMENT.md`.
3. Plan có mục **§12 "Điểm cần BA xác nhận" (Q1…Qn) chưa được trả lời** → **không code phần phụ thuộc
   câu hỏi đó**. Làm hết phần còn lại, liệt kê phần bỏ lại. Chỉ dừng toàn bộ khi Q chặn phần lớn API.
4. Module đích đã tồn tại → **đọc hết module đó trước**, làm theo kiểu "bổ sung vào cây có sẵn",
   không tạo module trùng, không âm thầm ghi đè.
5. Thư mục/tên module khác plan đề xuất → theo user.

## Kế hoạch

Toàn bộ file trong thư mục plan — `00-ke-hoach-tong.md`, mọi `NN-<chuc-nang>.md`,
`NN-thiet-ke-db.md`. Ràng buộc cứng cho code: §3 kiến trúc + cây thư mục · §4 danh mục API `A1…An` ·
§7 migration dự kiến · §10 quyền · §11 mã thông báo · §14 BR áp dụng.

## Rule & khung

- `CLAUDE.md` (gốc) + `cell-app/CLAUDE.md`
- `docs/rules/be-khung-kien-truc-chuan.md` — cây thư mục module, checklist artefact, cổng nghiệm thu
- `docs/rules/conventions-chung.md` + `docs/rules/conventions-be.md` — **KHÔNG** đọc `conventions.md` (đã tách; phần FE không liên quan)
- BR trong phạm vi: tra bảng ở `CLAUDE.md` rồi chạy `./docs/rules/br.sh <số BR>` (vd `./docs/rules/br.sh 7 30 39`). **KHÔNG đọc cả `business_rules.md`** — file nặng ~183 KB.

## Tài liệu PYC (khi plan trỏ tới, hoặc khi code thẳng từ PYC)

**Bước 0 — liệt kê thư mục PYC trước khi đọc**, đừng đoán tên (đa số epic dùng `5.screens/`
nhưng có epic dùng `4.screens/` hoặc `6.screens/`):

```bash
ls <thư-mục-PYC>/ && ls <thư-mục-PYC>/Matrix/
```

`4.usecases/**` · `3.crud-matrix.md` · `6.messages.md` (**nguyên văn** mã + nội dung thông báo) ·
`5.screens/**` · `Matrix/**` · `1.function-breakdown.md`.

⚠ Đặc tả màn có thể **rất lớn** (tới 187 KB/file). Chỉ đọc `SCR_*` của đúng chức năng đang làm.

## Code base phải kế thừa (khảo sát thật trước khi viết mới)

- `cell/core/` — `BaseCrudController` (8 endpoint), `BaseCrudService`, `BaseRepository`,
  `ApiResponse<T>`, `QuyenChecker`, `@Searchable` (tìm kiếm động), `GlobalExceptionHandler`
- `cell/accounting_core/` — `chung_tu.ChungTuTemplate` (khung chứng từ), `hach_toan.api.GhiSoApi`
  (**cửa duy nhất** để ghi sổ), `hach_toan.api.TaoDinhKhoanApi` (sinh bút toán từ bộ quy tắc),
  `khoa_so.api.ChungTuChoXuLyPort` (SPI đảo chiều cho module chứng từ)
- `cell/quan_he_chung_tu/` — tham chiếu chéo giữa chứng từ (BR41), đừng tự lưu khoá ngoại sang module khác
- Module mẫu: `cell/chung_tu_ban_hang/` · `cell/accounting_core/` · `cell/integration_ops/`
- Migration: version file mới = timestamp (`date +V%Y%m%d%H%M%S`), KHÔNG phải max + 1; `ls cell-app/src/main/resources/db/migration/` chỉ để xem bảng/cột đã có

**Vùng cấm:** `cell-app/**/cell/master_data/**` — KHÔNG đọc, KHÔNG lấy làm mẫu (`Read` bị deny ở
`.claude/settings.json`). Ngoại lệ duy nhất: user yêu cầu trực tiếp sửa `master_data`, hoặc module khác
lỗi biên dịch vì API công khai của nó — khi đó đọc **đúng** chữ ký cần dùng, **báo rõ cho user** là
đang chạm vùng đóng băng, và **xin phép** trước khi gỡ tạm rule deny.
