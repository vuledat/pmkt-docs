# Đọc bắt buộc + khảo sát — `/plan-be` bước 1–2

Đọc **hết**, không đọc lướt. Mỗi khẳng định trong plan phải trỏ được về nguồn thật.

## Rule & khung

- `CLAUDE.md` (gốc) + `cell-app/CLAUDE.md`
- `docs/rules/be-khung-kien-truc-chuan.md` — khung kiến trúc BE bắt buộc
- `docs/rules/conventions-chung.md` + `docs/rules/conventions-be.md`
- `docs/rules/_bieu-mau-plan-api.md` — **biểu mẫu chuẩn của file plan**, bám sát mục lục của nó
- BR trong phạm vi: tra bảng ở `CLAUDE.md` rồi chạy `./docs/rules/br.sh <số BR>` (vd `./docs/rules/br.sh 7 30 39`). **KHÔNG đọc cả `business_rules.md`** — file nặng ~183 KB.

## Tài liệu phiếu yêu cầu

- `1.function-breakdown.md` — chia chức năng ⇒ quyết định danh sách file con
- `2.usecase.puml`, `4.usecases/**` (mỗi UC có `UC_*.md` + `AD_*.puml`)
- `3.crud-matrix.md` (107/143 epic; `.puml` chỉ có ở vài epic)
- `6.messages.md` — mã & nội dung thông báo
- `5.screens/**` — `SCR_*.md` (**liệt kê `ls` trước**; file có thể tới 187 KB — chỉ đọc màn trong phạm vi)
- `Matrix/**` — ma trận ẩn/hiện, `_scope.md`

## Code base phải kế thừa (khảo sát, không copy mù)

- `cell/core/` — `BaseCrudController` (8 endpoint), `BaseCrudService`, `BaseRepository`,
  `ApiResponse<T>`, `QuyenChecker`, `@Searchable`
- `cell/accounting_core/` — `chung_tu.ChungTuTemplate`, `hach_toan.api.GhiSoApi` (ghi sổ),
  `khoa_so` (SPI chứng từ chờ xử lý)
- Module tham chiếu: `cell/chung_tu_ban_hang/`, `cell/integration_ops/`
- Migration: file mới đánh version theo timestamp (`date +V%Y%m%d%H%M%S`) — không cần dò số lớn nhất

**Vùng cấm:** `cell-app/**/cell/master_data/**` — KHÔNG đọc, KHÔNG lấy làm mẫu (`Read` bị deny ở
`.claude/settings.json`). Grep ra kết quả ở đó thì bỏ qua, không trích làm bằng chứng.

## Khảo sát — bắt buộc có bằng chứng

Trước khi viết chữ nào, phải trả lời được bằng lệnh thật:

| Câu hỏi | Cách trả lời |
|---|---|
| Greenfield hay brownfield? | `grep -rn "<từ khoá nghiệp vụ>" cell-app/src/main/java --include=*.java` |
| Bảng DB đã có chưa, bao nhiêu cột? | grep trong `cell-app/src/main/resources/db/migration/` |
| Version file migration mới? | `date +V%Y%m%d%H%M%S` — timestamp, không phải max + 1 |
| Base đã có sẵn thứ mình định viết chưa? | đọc `cell/core/`, `cell/accounting_core/` |
| Quyền đã seed chưa? | grep mã quyền trong migration/seed |

Ghi **lệnh đã chạy + kết quả thật** vào §2 file gốc. Không có `file:dòng` = chưa khảo sát xong,
không được viết "base đã có sẵn …" chung chung.
