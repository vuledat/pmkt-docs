---
name: plan-fe
description: Sinh kế hoạch triển khai màn hình frontend (client/) cho một phiếu yêu cầu BA. Dùng khi user gõ /plan-fe <đường dẫn thư mục PYC trong pmkt-docs/ba/> [link Figma] hoặc yêu cầu "lập kế hoạch FE / plan màn hình" cho một epic PMKT-E-xxxxx. Chỉ sinh tài liệu .md để dev + BA review, KHÔNG code.
---

# /plan-fe — Kế hoạch triển khai màn hình FE

**Đầu vào:** (1) thư mục phiếu yêu cầu, ví dụ `pmkt-docs/ba/PMKT-E-07528_KhoaSo` — bắt buộc;
(2) link Figma — tuỳ chọn nhưng **rất nên có**.

**Đầu ra:** thư mục `.md` gồm 1 file gốc + các file con theo từng màn/chức năng, để dev và BA review
**trước khi code**.

**Skill này KHÔNG code.** Không tạo/sửa `.tsx`, `.ts`, `.css`. Chỉ đọc code để trích `file:dòng`, chỉ
ghi `.md` trong thư mục đích.

**Hai nguồn sự thật:** Figma = UI · Matrix + UC = behavior. Conflict → **behavior theo Matrix, UI theo
Figma**, và ghi vào §11 + §12 (không tự chọn im lặng).

---

## Hai file tham chiếu — đọc đúng lúc

| Khi nào | Đọc |
|---|---|
| **Trước khi viết chữ nào** | `references/doc-va-khao-sat.md` — tài liệu bắt buộc · Figma · reuse · 4 câu hỏi khảo sát kèm bằng chứng |
| **Khi bắt đầu viết `.md`** | `references/mau-tai-lieu.md` — cây thư mục đầu ra · 16 mục của file gốc · khung file con · hợp đồng API/i18n |

---

## 0. Chốt đầu vào

1. Không có đường dẫn PYC → hỏi lại, **không đoán**.
2. Không có link Figma → hỏi user một lần. User không có thì vẫn làm tiếp, nhưng ghi rõ ở đầu file
   gốc: *"Chưa có Figma — đặc tả UI là suy ra từ `SCR_*.md`, phải review lại khi có design"*.
3. Suy ra `<slug>`: `PMKT-E-07528_KhoaSo` → `PMKT-E-07528-khoa-so`.
4. **Thư mục đích:** `docs/doing/<slug>-fe/`. User chỉ định khác thì theo user.
5. Thư mục đích đã tồn tại → hỏi ghi đè hay tạo bản mới; **không âm thầm ghi đè**.

---

## Luật viết — áp cho mọi dòng trong plan

- **Mọi khẳng định về code phải trỏ `file:dòng` thật.** Không viết "base đã có bảng ảo" chung chung.
- **Không đoán số đo UI.** Có Figma thì lấy số thật; không có thì ghi rõ là chưa xác định.
- **Reuse trước, viết mới sau** — mỗi component viết mới phải có dòng "đã kiểm `@base`/`@domain-kit`,
  không có sẵn vì …".
- **Không thêm field/logic/style/component ngoài scope**; không đề xuất refactor ngoài phạm vi.
- Type safety: không `any`, không `@ts-ignore`; dữ liệu ngoài phải qua Zod parse.
- Không `../../` — alias `@core`, `@base`, `@platform`, `@domain-kit`, `@features/*`, `@app/*`.
- Không hardcode text UI — mọi chuỗi có khoá i18n ở **cả** `vi.ts` và `en.ts`.
- Epic nói khác BR → epic thắng trong đúng phạm vi, và **phải ghi rõ đang lệch BR nào**.
- Thiếu quy định → đưa vào §12 hỏi BA, **không tự đặt luật mới**.

---

## Báo cáo khi xong

1. Đường dẫn thư mục đã sinh + danh sách file (1 câu mô tả mỗi file).
2. Quyết định thiết kế lớn (`D1…Dn`).
3. **Kế hoạch reuse** — dùng lại được gì, phải viết mới gì.
4. **Conflict Figma ↔ Matrix** (nếu có) — nêu ngay ở đây, không giấu cuối.
5. **Điểm cần BA / Design xác nhận** (`Q1…Qn`).
6. **BR đã áp dụng** và BR nào chưa xử lý được (kèm lý do).
7. Nhắc rõ: đây là **bản nháp chờ review**, chưa code gì.
