---
name: plan-be
description: Sinh kế hoạch triển khai API (backend cell-app) cho một phiếu yêu cầu BA. Dùng khi user gõ /plan-be <đường dẫn thư mục PYC trong pmkt-docs/ba/> hoặc yêu cầu "lập kế hoạch API / plan BE" cho một epic PMKT-E-xxxxx. Chỉ sinh tài liệu .md để dev + BA review, KHÔNG code.
---

# /plan-be — Kế hoạch triển khai API cho một phiếu yêu cầu

**Đầu vào:** thư mục phiếu yêu cầu, ví dụ `pmkt-docs/ba/PMKT-E-07528_KhoaSo`.

**Đầu ra:** thư mục `.md` gồm 1 file gốc + các file con theo từng chức năng, để dev và BA review
**trước khi code**.

**Skill này KHÔNG code.** Không tạo/sửa `.java`, `.sql`, `.ts`. Chỉ đọc code để trích `file:dòng`,
chỉ ghi `.md` trong thư mục đích.

---

## Hai file tham chiếu — đọc đúng lúc

| Khi nào | Đọc |
|---|---|
| **Trước khi viết chữ nào** | `references/doc-va-khao-sat.md` — tài liệu bắt buộc · base phải kế thừa · vùng cấm `master_data` · 5 câu hỏi khảo sát kèm bằng chứng |
| **Khi bắt đầu viết `.md`** | `references/mau-tai-lieu.md` — cây thư mục đầu ra · 16 mục file gốc · khung file con · khung thiết kế DB |

---

## Ba luật cứng về cấu trúc module (Modulith) — plan phải tuân, không cần mở file khác

`cell-app` là Spring Modulith: mỗi thư mục cấp 1 dưới `cell/` là một application module với
`package-info.java` khai `@ApplicationModule`.

1. **Mặc định là `internal/`.** Không đề xuất `api/` "cho chắc" — `chung_tu_ban_hang/` (module chứng
   từ đầy đủ nhất repo) không có `api/` nào. Chỉ tạo `api/` khi module KHÁC thật sự cần gọi vào.
2. **`api/` phải có `package-info.java` khai `@NamedInterface`** — lộ `x.api` KHÔNG tự động lộ
   `x.api.dto`; mỗi package con phải khai riêng, thiếu là Modulith chặn.
3. **Không đổ file phẳng ra gốc module.** Shape `controller/ dto/ entity/ repository/ service/` ở gốc
   (không có `internal/`) là shape cũ **đã đóng băng**.

Module lớn → chia sub-module trước rồi mới `api/ internal/`: `<module>/<sub>/api|internal/`.
**Đừng đề xuất viết lại khung** — `cell/core/` đã có `BaseCrudController` (8 endpoint),
`BaseCrudService`, `ApiResponse<T>`, `QuyenChecker`, tìm kiếm động qua `@Searchable`; chứng từ đi qua
`accounting_core.chung_tu.ChungTuTemplate`, ghi sổ **chỉ** qua `hach_toan.api.GhiSoApi`.

**Vùng cấm:** `cell-app/**/cell/master_data/**` — KHÔNG đọc, KHÔNG lấy làm mẫu (`Read` bị deny ở
`.claude/settings.json`). Mẫu đúng: `chung_tu_ban_hang/`, `accounting_core/`, `integration_ops/`.

---

## 0. Chốt đầu vào

1. Không có đường dẫn → hỏi lại, **không đoán**.
2. Thư mục không tồn tại → `ls pmkt-docs/ba/` rồi hỏi lại.
3. Suy ra `<slug>`: `PMKT-E-07528_KhoaSo` → `PMKT-E-07528-khoa-so`.
4. **Thư mục đích:** `docs/doing/<slug>-api/` (quy ước đang dùng — xem
   `../../../docs/done/PMKT-E-07528-khoa-so-api/`). User chỉ định khác thì theo user.
5. Thư mục đích **đã tồn tại** → hỏi *ghi đè* hay *tạo bản mới*; **không âm thầm ghi đè**.

---

## Luật viết — áp cho mọi dòng trong plan

- **Mọi khẳng định về code/DB phải trỏ `file:dòng` thật.** Không viết "base đã hỗ trợ tìm kiếm động"
  mà phải là `core/shared/search/DynamicSpecification.java:65`.
- **Mỗi lựa chọn thiết kế kèm "vì sao KHÔNG chọn phương án kia".**
- **Không bịa.** Không suy ra endpoint/cột/luật không có trong BA hoặc code. Thiếu → đưa vào §12 hỏi BA.
- Mâu thuẫn giữa tài liệu BA → trích bằng chứng **cả hai phía** rồi mới kết luận.
- Epic nói khác BR → epic thắng trong đúng phạm vi epic, và **phải ghi rõ đang lệch BR nào**.
- Text hiển thị giữ **nguyên văn tiếng Việt** của BA/BR (sẽ thành giá trị `vi.ts` ở FE).
- Không đề xuất viết lại thứ base đã có; không lấy `master_data/` hay `client/src/legacy/` làm mẫu.

---

## Báo cáo khi xong

1. Đường dẫn thư mục đã sinh + danh sách file (1 câu mô tả mỗi file).
2. **Quyết định thiết kế lớn** (`D1…Dn`) — tóm tắt.
3. **Điểm cần BA xác nhận** (`Q1…Qn`) — nêu ngay ở đây, đừng bắt user mở file mới thấy.
4. Rủi ro đáng chú ý.
5. **BR đã áp dụng** và BR nào chưa xử lý được (kèm lý do).
6. Nhắc rõ: đây là **bản nháp chờ review**, chưa code gì — duyệt xong thì chạy `/gen-be <thư mục plan>`.
