# Luật code BE — `/gen-be`

Bổ sung cho 8 luật ở `CLAUDE.md` gốc, **không thay thế**.

## Phân tầng

`Controller → Service → Repository → Entity`. Controller **không** chứa business logic, **không** gọi
Repository, **không** trả Entity ra ngoài. Mọi response bọc `ApiResponse<T>`; lỗi xử lý tập trung ở
`@RestControllerAdvice` (`core/config/GlobalExceptionHandler`), **không** try/catch rải trong controller.

`@RestController` để **package-private** — nó nằm trong `internal/controller/`, không ai ngoài module
được gọi thẳng.

## Kế thừa base — đừng dựng lại khung

| Cần | Dùng | Đừng |
|---|---|---|
| CRUD một bảng | `BaseCrudController` + `BaseCrudService` | tự viết 8 endpoint |
| Tìm kiếm / lọc động | `@Searchable` trên entity | tự ghép JPQL |
| Chứng từ kế toán | `accounting_core.chung_tu.ChungTuTemplate` | tự viết luồng lưu/sửa/xoá |
| Ghi sổ | `hach_toan.api.GhiSoApi` | tự insert vào sổ cái |
| Sinh bút toán | `hach_toan.api.TaoDinhKhoanApi` + bộ quy tắc | tự dựng dòng sổ cái trong module |
| Tham chiếu chéo chứng từ | `quan_he_chung_tu.api.QuanHeChungTuApi` | khoá ngoại sang module khác |
| Chứng từ chờ xử lý (khoá sổ) | cắm `khoa_so.api.ChungTuChoXuLyPort` | để khoa_so biết từng loại chứng từ |
| Kiểm quyền | `QuyenChecker` (BR25) | tự đọc bảng quyền |

Base thiếu một thứ nhỏ → **bổ sung vào base** (backward-compatible), **không** copy khung ra module.

## Modulith — ranh giới

- Mặc định mọi thứ ở `internal/`. Chỉ tạo `api/` khi module KHÁC thật sự cần gọi vào.
- `api/` và mỗi package con của nó phải có `package-info.java` khai `@NamedInterface`.
- Không import `internal/` của module khác. Cần dữ liệu → qua `api/` của họ, hoặc **đảo chiều** bằng
  port + adapter (mẫu: `chung_tu_ban_hang/internal/adapter/ChungTuBanHangChoXuLyAdapter`).
- Thêm module mới → cân nhắc thêm test ranh giới ở `arch/ProxyModularityTest` như `khoa_so` đã làm.

## Entity · DTO · DB

- DTO có hậu tố `…Request` / `…Response` / `…Dto`; constructor injection với `@RequiredArgsConstructor`.
- Bảng/cột DB `snake_case`. Migration Flyway `V<yyyyMMddHHmmss>__<mo_ta_khong_dau>.sql` (version lấy bằng
  `date +V%Y%m%d%H%M%S`, KHÔNG dùng `max+1`), **không sửa migration
  đã chạy** — luôn thêm file mới.
- BR7 precision & làm tròn · BR19 kiểm trùng · BR20 số chứng từ & mã danh mục · BR28 multi-tenant
  (RLS — mọi bảng nghiệp vụ có `tenant_id`) · BR29 chính sách xoá (xoá mềm) · BR46 trường hệ thống
  bắt buộc (`ngay_tao`, `nguoi_tao`, `ngay_cap_nhat`, `nguoi_cap_nhat`…).
- Migration đi **cùng commit** với code dùng nó.

## Thông báo & lỗi

Mã + nội dung lấy **nguyên văn** `6.messages.md` — không tự diễn đạt lại. Exception nghiệp vụ ném từ
service, map sang HTTP status ở `GlobalExceptionHandler`, không trả 500 trần cho lỗi nghiệp vụ.

## Tương tranh

Chức năng ghi phải nêu rõ ranh giới `@Transactional`, khoá lạc quan (`updatedAt` làm token), và
idempotency nếu endpoint có thể bị gọi lại (mẫu: `RequestHash` ở `hach_toan/internal/ghi_so`).

## Phạm vi

- **Chỉ code đúng phạm vi plan.** Không tự thêm endpoint/cột/luật ngoài scope; không refactor ngoài
  phạm vi; code cũ vi phạm chỉ dọn trong đúng phần đang sửa.
- **Lệch plan phải khai báo** — ghi `IMPLEMENT.md` mục "Lệch so với plan" (lệch gì · vì sao · ảnh
  hưởng). Lệch làm đổi hợp đồng API hoặc đổi nghiệp vụ → **hỏi user trước**.
- **Không tự đặt luật nghiệp vụ mới.** BR/BA chưa phủ → hỏi user.
- Epic nói khác BR → epic thắng trong đúng phạm vi epic, **ghi rõ đang lệch BR nào**.

## Test

- Đặt cạnh cây `src/test/java/...` gương với `src/main/java/...`.
- **Ưu tiên unit test thuần JVM, gắn `@Tag("unit")`** — đó là cổng chạy được trên máy này.
- Test cần Testcontainers (DB thật, Redis, MinIO) → **vẫn viết** nếu plan yêu cầu, nhưng **không chạy**
  (máy cấm Docker), và **nói rõ trong báo cáo** là chưa chạy.
