---
name: gen-be
description: Sinh code API backend (cell-app) từ kế hoạch BE đã review. Dùng khi user gõ /gen-be <đường dẫn thư mục plan trong docs/doing/*-api/ hoặc thư mục PYC trong pmkt-docs/ba/> hoặc yêu cầu "code API / gen BE / triển khai plan BE" cho một epic PMKT-E-xxxxx. Skill này SINH CODE JAVA THẬT trong cell-app/, khác với /plan-be (chỉ sinh .md), và luôn xuất file Postman collection vào docs/json/.
---

# /gen-be — Sinh code API từ kế hoạch BE

**Đầu vào:** (1) thư mục plan BE do `/plan-be` sinh, ví dụ `../../../docs/done/PMKT-E-07528-khoa-so-api` —
**ưu tiên số 1**; user đưa thẳng thư mục PYC mà chưa có plan → xử lý theo `references/doc-bat-buoc.md`
mục "Chốt đầu vào". (2) phạm vi hẹp tuỳ chọn: `/gen-be <plan> 01,02`.

**Đầu ra:**
- code Java thật trong `cell-app/src/main/java/vn/vtt/pmkt/cell/<module>/`
- migration Flyway trong `cell-app/src/main/resources/db/migration/`
- test trong `cell-app/src/test/java/...`
- **`docs/json/<slug>.postman_collection.json`** — BẮT BUỘC, xem `references/swagger-va-postman.md`
- `IMPLEMENT.md` trong thư mục plan

**Nguồn sự thật:** plan BE (đã review) → BA (`4.usecases/`, `6.messages.md`, `Matrix/`) → BR chung.
Plan sai/thiếu → sửa theo hướng đúng **và khai báo**; đổi hợp đồng API hoặc đổi nghiệp vụ → **hỏi user**.

---

## Bốn file tham chiếu — đọc đúng lúc, không đọc trước hết

| Khi nào | Đọc |
|---|---|
| **Trước dòng code đầu tiên** | `references/doc-bat-buoc.md` — chốt đầu vào · tài liệu bắt buộc · base phải kế thừa · vùng cấm `master_data` |
| **Trong lúc sinh code** | `references/luat-code.md` — phân tầng · kế thừa base · ranh giới Modulith · entity/DB/migration · tương tranh · luật test |
| **Bước 12 — xuất đặc tả API** | `references/swagger-va-postman.md` — lấy `/v3/api-docs` qua IntelliJ, dựng collection v2.1.0 vào `docs/json/` |
| **Trước khi báo hoàn thành** | `references/cong-va-bao-cao.md` — cổng `unitTest` · cấm Docker · luật đỏ · `IMPLEMENT.md` · mẫu báo cáo |

---

## Ba luật cứng về cấu trúc (Modulith) — không cần mở file khác

1. **Mặc định là `internal/`.** Chỉ tạo `api/` khi module KHÁC thật sự cần gọi vào —
   `chung_tu_ban_hang/` không có `api/` nào.
2. **`api/` phải có `package-info.java` khai `@NamedInterface`**, mỗi package con khai riêng
   (lộ `x.api` KHÔNG tự động lộ `x.api.dto`).
3. **Không đổ file phẳng ra gốc module.** Shape `controller/ dto/ entity/ repository/ service/` ở gốc
   (không có `internal/`) là shape cũ **đã đóng băng**.

Mẫu đúng: `cell/chung_tu_ban_hang/` · `cell/accounting_core/` · `cell/integration_ops/`.
Vùng cấm: `cell/master_data/**`.

**Không dựng lại khung** — `core/` đã có `BaseCrudController` · `BaseCrudService` · `ApiResponse<T>` ·
`QuyenChecker` · `@Searchable`; chứng từ đi qua `ChungTuTemplate`; ghi sổ **chỉ** qua `GhiSoApi`.

---

## Trình tự sinh code — theo đúng thứ tự này

Sinh theo lát cắt dọc để mỗi bước đều compile được.

| Bước | Sinh gì | Ghi chú |
|---|---|---|
| 1 | `<module>/package-info.java` khai `@ApplicationModule` | thiếu là Modulith không nhận module |
| 2 | Migration `V<yyyyMMddHHmmss>__…sql` | version = `date +V%Y%m%d%H%M%S` (KHÔNG dùng `max+1`); tenant_id + trường hệ thống BR46; **không sửa migration đã chạy** |
| 3 | `internal/entity/` | `snake_case` bảng/cột, `@Searchable` cho cột cần lọc, BR7 precision |
| 4 | `internal/repository/` | kế thừa `BaseRepository`, chỉ thêm query thật sự cần |
| 5 | `internal/dto/` | hậu tố `…Request` / `…Response` / `…Dto` |
| 6 | `internal/service/business/` — validator · mapper · tính toán | hàm nghiệp vụ thuần, dễ unit test |
| 7 | `internal/service/` — service chính | kế thừa `BaseCrudService` / `ChungTuTemplate`; ghi sổ qua `GhiSoApi` |
| 8 | `internal/port/` + `internal/adapter/` (nếu cần) | đảo chiều thay vì import `internal/` module khác |
| 9 | `api/` + `package-info.java` (**chỉ khi** module khác cần) | `@NamedInterface`, DTO riêng, không lộ entity |
| 10 | `internal/controller/` — **package-private** | không logic, không gọi repository, trả `ApiResponse<T>` |
| 11 | `src/test/java/...` | ưu tiên `@Tag("unit")` thuần JVM; test Testcontainers vẫn viết nhưng **không chạy** |
| 12 | **`docs/json/<slug>.postman_collection.json`** | BẮT BUỘC — `references/swagger-va-postman.md` |

**Giữa chừng** (sau bước 7 và 10): `cd <REPO>/cell-app && ./gradlew unitTest`, hoặc
`mcp__idea__get_file_problems` cho file vừa sửa. **Không** `./gradlew build`, **không** Docker.
