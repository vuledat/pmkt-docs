# Quy trình verify trước khi publish

Bốn cổng, chạy tuần tự. Cổng đỏ thì sửa rồi chạy lại từ cổng đó, **không** publish để "xem sau".

---

## Cổng 1 — cân bằng thẻ HTML

```bash
python3 - <<'PY'
import re
s=open('docs/html/<PYC>/<slug>-flow.src.html',encoding='utf-8').read()
for t in ['section','figure','table','div','pre','nav','main','header','footer','tbody','thead','tr']:
    o=len(re.findall(r'<%s[\s>]'%t,s)); c=len(re.findall(r'</%s>'%t,s))
    print(f"{t}: {o}/{c} {'OK' if o==c else '<<< LỆCH'}")
print("số sơ đồ:", s.count('class="mermaid"'))
PY
```

---

## Cổng 2 + 3 — parse mermaid và đo bề rộng

Artifact tự render mermaid nên **không** kiểm được bằng cách mở file trực tiếp. Dựng bản test có
nhúng mermaid từ CDN, phục vụ qua HTTP nội bộ rồi lái bằng Browser pane.

```bash
cd <thư mục scratchpad>
{ printf '%s\n' '<!doctype html><html><head><meta charset="utf-8">';
  cat <file>.html;
  printf '%s\n' '</head><body>';
  printf '%s\n' '<script type="module">import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";window.__errs=[];try{mermaid.initialize({startOnLoad:false});const els=[...document.querySelectorAll("pre.mermaid")];for(let i=0;i<els.length;i++){try{await mermaid.parse(els[i].textContent);}catch(e){window.__errs.push(i+": "+e.message);}}await mermaid.run({nodes:els});}catch(e){window.__errs.push("init: "+e.message);}window.__done=true;</script>';
  printf '%s\n' '</body></html>'; } > test-render.html
(python3 -m http.server 8791 >/dev/null 2>&1 &)
```

Mở `http://localhost:8791/test-render.html` bằng `preview_start` / `tabs_create` + `navigate`, rồi
chạy `javascript_tool`:

```js
(()=>{const r=[];document.querySelectorAll('pre.mermaid').forEach((p,i)=>{
  const s=p.querySelector('svg'); const bb=s?s.getBoundingClientRect():null;
  r.push(bb?[i,Math.round(bb.width),Math.round(bb.height)]:[i,null]);});
 return JSON.stringify({done:window.__done,errs:window.__errs,
  noHScroll:document.documentElement.scrollWidth<=document.documentElement.clientWidth,r});})()
```

Chờ tới khi `done:true` rồi mới đọc kết quả — mermaid render bất đồng bộ, gọi sớm sẽ thấy thiếu SVG.

| Kết quả | Nghĩa | Xử lý |
|---|---|---|
| `errs` khác rỗng | sai cú pháp mermaid | xem bẫy 6 ở `khung-html.md`; index trong chuỗi lỗi là thứ tự block |
| SVG nào `null` sau `done:true` | block đó chết khi render | rút gọn nhãn, bỏ ký tự lạ |
| `noHScroll:false` | thân trang cuộn ngang | thiếu `overflow-x:auto` ở `.plate` hoặc `.tw` |
| bề rộng > ~1800px | phải cuộn quá nhiều | đổi hướng TD↔LR **và đo lại**, hoặc tách thành hai sơ đồ, hoặc gộp nhánh chi tiết xuống bảng |

Tách sơ đồ là cách hạ bề rộng hiệu quả nhất: chuỗi validate tách khỏi chuỗi ghi dữ liệu, luồng đơn
tách khỏi luồng hàng loạt. Hai `subgraph` cạnh nhau trong một block là công thức sinh SVG rộng 4500px.

---

## Cổng 4 — đo lẹm chữ (bắt buộc, không thay bằng nhìn ảnh)

Chạy trên trang đã render:

```js
(()=>{let tot=0,clip=0,max=0,ex=[];document.querySelectorAll('pre.mermaid foreignObject').forEach(fo=>{
  const d=fo.firstElementChild; if(!d) return; tot++;
  const o=d.getBoundingClientRect().width-fo.getBoundingClientRect().width;
  if(o>0.5){clip++;max=Math.max(max,o); if(ex.length<5) ex.push([d.textContent.slice(0,24),+o.toFixed(1)]);}});
 return JSON.stringify({tot,clip,max:+max.toFixed(1),ex});})()
```

| Kết quả | Xử lý |
|---|---|
| `clip: 0` | đạt |
| `clip > 0` | dính **bẫy 1** — font khai scope vào `.plate` nên lúc mermaid đo (ở container tạm gắn `<body>`) không áp. Chuyển khối font sang phạm vi toàn trang + `foreignObject{overflow:visible}`, render lại, đo lại |

**Không** dùng `d.scrollWidth - d.clientWidth` để đo — `div` nhãn co theo nội dung nên hai số luôn
bằng nhau, chỉ số này bỏ sót toàn bộ lỗi lẹm chữ.

Sửa xong phải **render lại từ đầu** rồi mới đo: đổi CSS trên trang đã render không làm mermaid tính
lại bề rộng hộp.

---

## Cổng 5 — nhìn bằng mắt

`resize_window` khoảng `820×620` để ảnh chụp đúng tỉ lệ 1:1 (viewport rộng hơn sẽ bị thu nhỏ khi chụp).

```js
(()=>{const pl=document.querySelectorAll('.plate')[6];
  pl.scrollIntoView({block:'start'}); pl.scrollLeft=250; return 'ok';})()
```

rồi `computer{action:"screenshot"}`. Kiểm:

- nhãn node hiện **đủ chữ**, không cụt đuôi → cụt thì quay lại bẫy 1 và 2;
- màu ô lỗi/thành công/cảnh báo đúng vai trò;
- chạy lại với `colorScheme:"dark"` — nền `.plate` vẫn sáng, chữ trong sơ đồ vẫn đọc được.

Đo bổ sung khi nghi cắt chữ:

```js
getComputedStyle(document.querySelector('pre.mermaid .nodeLabel')).fontFamily
```

Trả về `monospace` là **đang dính bẫy 1**. Phải ra đúng stack Helvetica.

---

## Cổng 6 — xuất bản standalone cho `docs/`

Bản `.src` **không** mở trực tiếp được: thiếu `<meta charset>` → mojibake toàn bộ dấu tiếng Việt
(`Chá»©ng tá»«`), và không có runtime mermaid → khung sơ đồ trống. Phải xuất bản standalone có SVG
render sẵn.

Không kéo HTML đã render qua context của model — cho trình duyệt **POST thẳng vào server ghi file**:

```python
# save-server.py — chạy trong scratchpad
import http.server, socketserver
class H(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        open('standalone.html','wb').write(self.rfile.read(int(self.headers.get('Content-Length',0))))
        self.send_response(200); self.send_header('Content-Length','2'); self.end_headers()
        self.wfile.write(b'ok')
socketserver.TCPServer.allow_reuse_address=True
with socketserver.TCPServer(('127.0.0.1',8792),H) as s: s.serve_forever()
```

`export.html` đặt cạnh bản `.src`, mở bằng Browser pane rồi để nó tự làm:

```html
<!doctype html><html><head><meta charset="utf-8"></head><body><div id="host"></div>
<script type="module">
import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
document.getElementById('host').innerHTML = await (await fetch('./<slug>-flow.src.html')).text();
const head=[];                       // style + link của trang phải lên <head> thì CSS mới áp khi render
document.querySelectorAll('#host style,#host link').forEach(el=>{head.push(el.outerHTML); el.remove();});
const t=document.createElement('div'); t.innerHTML=head.join('\n');
[...t.children].forEach(c=>document.head.appendChild(c));
mermaid.initialize({startOnLoad:false});
await mermaid.run({nodes:[...document.querySelectorAll('pre.mermaid')]});
await new Promise(r=>setTimeout(r,1500));            // chờ layout ổn định trước khi serialize
const title=document.querySelector('#host title')?.textContent||'Luồng xử lý';
document.querySelectorAll('#host title').forEach(el=>el.remove());
await fetch('/save',{method:'POST',body:
  '<!doctype html>\n<html lang="vi">\n<head>\n<meta charset="utf-8">\n'
+ '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
+ '<title>'+title+'</title>\n'+head.join('\n')+'\n</head>\n<body>\n'
+ document.getElementById('host').innerHTML+'\n</body>\n</html>\n'});
window.__done=true;
</script></body></html>
```

Kiểm bản xuất trước khi copy vào `docs/html/<PYC>/`:

```python
s=open('standalone.html',encoding='utf-8').read()
print('charset:', '<meta charset="utf-8">' in s)   # phải True
print('svg:', s.count('<svg '))                     # phải bằng số sơ đồ
print('còn pre chưa render:', s.count('class="mermaid"')-s.count('data-processed'))  # phải 0
print('tiếng Việt:', 'Chứng từ' in s)               # phải True — sai là đọc/ghi lệch encoding
```

File standalone nặng ~1MB cho 15 sơ đồ là bình thường (mỗi SVG mang CSS riêng).

> **Lưu ý khi chụp màn hình trang dài:** ở vị trí cuộn sâu (>15.000px) Browser pane hay trả về ảnh
> trắng dù trang vẫn đúng. Kiểm chéo bằng `getBoundingClientRect()` của một `.node` — có tọa độ nằm
> trong viewport là trang vẫn ổn, đừng sửa mù theo ảnh trắng.

---

## Cổng 7 — link trên trang tổng hợp

Sau khi thêm thẻ vào `docs/html/tong_hop.html`, mọi link nội bộ phải resolve. Trang này không có
mermaid nên chỉ cần một phép kiểm:

```bash
cd docs/html && python3 - <<'EOF'
import re, os
s = open('tong_hop.html', encoding='utf-8').read()
bad = 0
for l in sorted(set(re.findall(r'href="([^"]+)"', s))):
    if l.startswith('http'):
        continue
    ok = os.path.exists(l)
    bad += 0 if ok else 1
    print('OK  ' if ok else 'THIEU', l)
print('cards:', s.count('<article'), '| link hong:', bad)
EOF
```

`link hong` phải bằng **0** và `cards` phải bằng số epic đang có trong `docs/html/`.

Kiểm chéo nhanh số liệu trên thẻ: số mục = số `<section id="s...">` trong bản `.src`, số sơ đồ =
số `<pre class="mermaid">`.

```bash
grep -c '<section id="s' docs/html/<PYC>/<slug>-flow.src.html
grep -c 'class="mermaid"' docs/html/<PYC>/<slug>-flow.src.html
```

---

## Publish

```
Artifact{ file_path, favicon, description }
```

Cập nhật lần sau: publish lại **đúng đường dẫn file đó** để giữ nguyên URL. Sửa từ phiên khác thì
truyền `url` của artifact cũ; publish không kèm `url` sẽ đẻ ra artifact thứ hai.

Dọn sau khi xong: tắt `python3 -m http.server`, xóa `test-render.html` trong scratchpad.
