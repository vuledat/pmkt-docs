# Luật code FE — `/gen-fe`

Bổ sung cho 8 luật ở `CLAUDE.md` gốc, **không thay thế**. Đọc trước khi sinh code (bước 1 trở đi).

## Reuse

- **Reuse trước, viết mới sau.** Mỗi component tự viết phải có comment một dòng ngay trên khai báo:
  `// đã kiểm @base/@domain-kit — không có sẵn vì <lý do>`.
- Thiếu prop nhỏ ở component `@base` → **thêm prop vào `@base`** (backward-compatible, mặc định
  không đổi hành vi cũ), **không** copy component ra feature.
- Có engine `@domain-kit` phù hợp → dùng descriptor, không dựng lại khung CRUD.

## Type & dữ liệu

- Không `any`, không `@ts-ignore`, không `as unknown as`. Dùng `unknown` + type guard, hoặc Zod parse.
- **Mọi dữ liệu từ mạng phải qua Zod parse**, kể cả khi BE "chắc chắn trả đúng".

## Text & số

- Không hardcode chuỗi người dùng thấy — khoá i18n ở **cả** `vi.ts` và `en.ts`. Chuỗi động dùng
  interpolation `t('key', { name })`, **không cộng chuỗi**.
- Không hardcode magic value — constant có tên, đặt gần nơi dùng nhất.

## Phạm vi

- **Chỉ code đúng phạm vi plan.** Không tự thêm field, logic, style, component ngoài scope; không
  refactor ngoài phạm vi; code cũ vi phạm quy tắc chỉ dọn trong đúng phần đang sửa.
- **Lệch plan phải khai báo.** Phát hiện plan sai/thiếu → sửa theo hướng đúng, ghi vào `IMPLEMENT.md`
  mục "Lệch so với plan" (lệch gì · vì sao · ảnh hưởng), nêu lại trong báo cáo. Lệch làm đổi hợp
  đồng API hoặc đổi nghiệp vụ → **hỏi user trước**.
- **Không tự đặt luật nghiệp vụ mới.** BR/Matrix chưa phủ → hỏi user; không code theo suy đoán.
- Epic nói khác BR → epic thắng trong đúng phạm vi epic, và **phải ghi rõ đang lệch BR nào**.

## Test — viết sao cho suite không chậm thêm

Luật đầy đủ ở `client/CLAUDE.md §13`.

- **BẮT BUỘC `// @vitest-environment node` ở DÒNG ĐẦU** mọi `*.test.ts` không chạm DOM. Thiếu dòng
  này thì file tự dựng một jsdom riêng, tốn ~5s. Đo 2026-08-13 trên 116 file logic thuần:
  **28,1s → 14,5s**, chi phí `environment` 102,5s → 11ms. File `.tsx`, hoặc `.ts` có `render()` /
  `document` / `window` / `localStorage` / `matchMedia` / `@testing-library` → **không** khai.
- **Không import barrel trong test**: `import { X } from '@base'` kéo cả 290 dòng export (~219
  component + antd + exceljs + recharts) vào mọi worker — chi phí `import` lớn nhất của suite
  (955s cộng dồn). Import thẳng đường dẫn cụ thể.
- Logic thuần (`helpers/`, `fields/`, `api/` schema) → `*.test.ts` + docblock `node`, **không**
  `render()`. Chỉ `render()` cho `components/` và `pages/`.

## Class semantic — locator automation test

Luật đầy đủ ở [`docs/rules/fe-semantic-class-rule.md`](../../../../docs/rules/fe-semantic-class-rule.md)
— đọc trước khi sinh bước 7 (`components/`) và bước 8 (`pages/`). Class semantic dùng luôn làm
locator test, **không** gắn thêm `data-testid`.

- Class kebab-case, phân cấp theo DOM hierarchy `domain > screen > surface/action > field/item`
  (vd. `ban-hang` > `chung-tu-ban-hang` > `create` > `so-chung-tu`), mỗi element chỉ mang class cấp
  của chính nó — không nối cả path vào một class.
- `surface/action` dùng đúng canonical term trong controlled vocabulary (`create`, `delete`,
  `reload`... không `add`/`remove`/`refresh`).
- Row/item lặp: class chỉ xác định loại phần tử, **không** dùng index/STT; instance dùng
  `data-pmkt-owner-key`/key riêng.

## Nợ kỹ thuật

API BE chưa có → `api/mock.ts` tạm, đánh dấu rõ trong file (`// TODO nợ: chờ endpoint <path>`) và ghi
vào `IMPLEMENT.md`. **Còn `mock.ts` = còn nợ**, phải nêu trong báo cáo hoàn thành.
