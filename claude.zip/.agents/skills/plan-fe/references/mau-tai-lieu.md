# Mẫu tài liệu đầu ra — `/plan-fe` bước 3–6

## Cấu trúc thư mục đầu ra

```
docs/doing/<slug>-fe/
├── 00-ke-hoach-tong.md          ← file gốc, bắt buộc
├── 01-<man-hinh-1>.md           ← một file / một màn hoặc popup (bám 5.screens + Matrix)
├── 02-<popup-…>.md
└── NN-hop-dong-api-va-i18n.md   ← hợp đồng Zod với BE + bảng khoá i18n vi/en
```

Tên file con: 2 chữ số + kebab-case tiếng Việt không dấu, bám tên `SCR_*`
(`01-xem-danh-sach-thiet-lap.md`, `03-popup-chon-loai-chung-tu.md`).

## `00-ke-hoach-tong.md` — 16 mục

| § | Nội dung | Ghi chú bắt buộc |
|---|---|---|
| header | Trạng thái · ngày · người review (1 BA + 1 Dev FE + 1 Design) · bảng: UC · màn hình · link Figma · module FE · domain · API phụ thuộc | |
| 0 | Quyết định đã chốt `D1…Dn` | quyết định + **hệ quả cụ thể lên code**; kèm "vì sao KHÔNG chọn phương án kia" |
| 1 | Phạm vi — trong / **NGOÀI** phạm vi | nêu đích danh mã UC/SCR bị loại |
| 2 | Hiện trạng đã khảo sát | 4 câu hỏi + tình trạng API BE, kèm lệnh đã chạy |
| 3 | **Kế hoạch reuse** | bảng: "Cần / Có sẵn ở đâu (`file:dòng`) / Dùng lại hay viết mới / Lý do". Thiếu prop nhỏ → **thêm prop vào `@base`**, không copy ra feature |
| 4 | Kiến trúc module — cây thư mục sẽ sinh | cây phẳng 1 bậc; gốc module **chỉ có `index.ts`**; popup vào `components/modal/`; không tạo thư mục rỗng |
| 5 | Checklist artefact | bám bảng 15 dòng ở `docs/rules/fe-khung-kien-truc-chuan.md §5` |
| 6 | Route & quyền | `routes.tsx` (handle DATA-ONLY, perm, crumbKeys) + nối tay `RootRoutes.tsx` + mã quyền (BR25) |
| 7 | Bản đồ màn ↔ file con ↔ SCR ↔ UC ↔ Matrix | mọi `SCR_*.md` phải xuất hiện đúng 1 lần |
| 8 | i18n — **một namespace cho cả module** | tên namespace, cây khoá (popup là nhánh con `themMoi.*`), nguồn chữ = nguyên văn BA/BR |
| 9 | Thứ tự thực hiện | chia bước + phụ thuộc giữa file con và phụ thuộc vào API BE |
| 10 | Rủi ro `R1…Rn` | kèm cách giảm thiểu |
| 11 | **Conflict Figma ↔ Matrix** | bảng: điểm conflict · Figma nói gì · Matrix nói gì · xử lý |
| 12 | ⚠️ Điểm cần BA / Design xác nhận `Q1…Qn` | mâu thuẫn phải trích bằng chứng **cả hai phía** |
| 13 | Kiểm thử + cổng nghiệm thu | cổng nhẹ: `npx vitest run src/features/<domain>/<module> --reporter=dot` + `npx vite build` + `check:committed`. Bốn lệnh nặng (`typecheck`/`lint`/`lint:boundaries`/full suite) **không** chạy mặc định — xem `/gen-fe references/cong-va-bao-cao.md` |
| 14 | BR áp dụng | mã BR + áp ở đâu |
| 15 | Tài liệu tham chiếu | |

Mục không áp dụng → ghi `Không áp dụng — <lý do>`, **không xoá tiêu đề**.
Đánh số dùng chéo: `D…` quyết định · `F…` chức năng · `R…` rủi ro · `Q…` câu hỏi.

## Mỗi file con `NN-<man-hinh>.md` — chỗ user cần chi tiết nhất

1. **Header** — mã màn, `SCR_*` nguồn, UC nguồn, node Figma, đường dẫn route.
2. **Bố cục** — mô tả vùng (header/filter/grid/footer/popup), kèm ảnh hoặc mô tả khung từ Figma.
3. **Đặc tả UI từ Figma** — bảng: thành phần · component `@base` dùng lại · kích thước · spacing ·
   typography · màu · biến thể. Không có Figma thì ghi rõ "suy ra từ SCR".
4. **Ma trận ẩn/hiện · required · disabled** — dịch **nguyên vẹn** từ `Matrix/*_MaTranAnHien.md`
   thành bảng: thành phần × trạng thái (Thêm/Sửa/Xem/…). Đây là đầu vào trực tiếp cho
   `helpers/anHien.ts`.
5. **Bảng cột / trường** — tên hiển thị · khoá i18n · field API · kiểu · định dạng (BR7 precision) ·
   độ rộng · sort được? · lọc được? · mặc định ẩn/hiện (BR30).
6. **Hành vi & sự kiện** — mỗi nút/thao tác: điều kiện hiện, điều kiện disable, việc làm, confirm,
   toast, invalidate query. Bám BR13 · BR14 · BR26.
7. **Validation phía FE** — mỗi luật: điều kiện · thông báo (nguyên văn `6.messages.md`) · BR nguồn.
   Nêu rõ luật nào **chỉ** BE kiểm, FE chỉ hiển thị lỗi trả về.
8. **Luồng xử lý** — bước đánh số, gọi hook nào, API nào, xử lý loading/empty/error.
9. **Phân bổ file** — bảng: việc → file cụ thể trong module, theo cây quyết định
   `fe-khung-kien-truc-chuan.md §3.2`.
10. **Kiểm thử** — mỗi case: input → kỳ vọng. Ghi rõ case nào **logic thuần** (`*.test.ts` + docblock
    `// @vitest-environment node`) và case nào cần DOM (`*.test.tsx`, chỉ cho `components/`/`pages/`).
    Test **không** import barrel `@base`.
11. **BR đã áp dụng**.

## `NN-hop-dong-api-va-i18n.md`

1. **Hợp đồng với BE** — mỗi endpoint: method · path · request/response JSON mẫu · Zod schema dự kiến
   (`api/model.ts`) · query key. Trỏ về plan BE `docs/doing/<slug>-api/` nếu có.
2. **Trạng thái API** — endpoint nào đã có thật, endpoint nào chưa (⇒ `mock.ts` tạm, ghi rõ là nợ).
3. **Bảng khoá i18n** — cột: khoá · `vi` (nguyên văn BA/BR) · `en`. Chuỗi động dùng interpolation,
   **không cộng chuỗi**. Một namespace duy nhất cho cả module.
4. **Hằng số nghiệp vụ** — magic value sẽ vào `constants/constants.ts`, SCREAMING_SNAKE_CASE.
5. **Mã quyền** — `constants/permissions.ts` (BR25).
6. **Đường dẫn** — `constants/paths.ts`; ngoài module deep-import thẳng vào file này.
