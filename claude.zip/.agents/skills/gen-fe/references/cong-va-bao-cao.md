# Cổng nghiệm thu + báo cáo — `/gen-fe`

Đọc ở **bước cuối**, trước khi báo hoàn thành.

**Dùng đường dẫn tuyệt đối tới `client/`** trong mọi lệnh — cwd hay bị reset về gốc repo, `tsc` khi đó
im lặng báo "0 lỗi" giả và `vitest` báo "no test files found" giả. `<REPO>` = đường dẫn tuyệt đối tới
gốc repo của phiên (thay bằng đường dẫn thật).

## 1. Trong vòng lặp code

Mặc định chạy đúng **thư mục module đích** (~30–60s):

```bash
cd <REPO>/client && npx vitest run src/features/<domain>/<module> --reporter=dot
```

Chỉ khi vừa sửa **một file lá** (helper, hook, component cụ thể) mới dùng `related`:

```bash
cd <REPO>/client && npx vitest related --run <file lá vừa sửa> --reporter=dot
```

⚠ **Không `related` trên file barrel / dùng chung** (`index.ts`, `@base`, `@core`, i18n gốc) — đo
thực tế `related --run src/utils/index.ts` kéo **217 file, 3 phút 54**, chậm hơn chạy thẳng module.

- **Luôn `--reporter=dot`**; không chạy coverage.
- **Không chạy `npm run typecheck`** giữa chừng — 55s/lần, nền đã 192 lỗi.

## 2. Cổng nhẹ — chạy MỘT lần trước khi báo hoàn thành

Ba lệnh, ~3,5 giây cộng thời gian test module đích. Hai lệnh sau độc lập → phát song song:

```bash
cd <REPO>/client && npx vitest run src/features/<domain>/<module> --reporter=dot
```
```bash
cd <REPO>/client && npx vite build
```
```bash
cd <REPO>/client && npm run check:committed   # chỉ khi có commit
```

⚠ **`npx vite build`, KHÔNG phải `npm run build`.** `npm run build` chạy `tsc -b` trước và luôn đỏ ở
192 lỗi nền, nên **chưa bao giờ chạy tới bước bundle**. `npx vite build` (2,3s) mới đúng thứ CI dựng,
và là thứ bắt được sự cố `khoaSo.css` (2026-08-13: một `*/` lạc trong comment giết bước minify CSS).

## 3. Bốn lệnh nặng — KHÔNG chạy mặc định (user chốt 2026-08-13)

`npm run typecheck` (~55s) · `npm run lint` (~60s) · `npm run lint:boundaries` (~60s) ·
`npx vitest run --exclude 'src/legacy/**'` (~4,5 phút / 370 file).

Chỉ chạy khi **user yêu cầu**, hoặc khi việc vừa làm đúng vào vùng chúng canh:

| Vừa làm gì | Chạy thêm |
|---|---|
| đụng `src/base/index.ts` hoặc barrel bất kỳ | `typecheck` |
| thêm import xuyên tầng / alias mới | `lint:boundaries` |
| sửa `@base` hoặc engine `@domain-kit` dùng chung | full suite |
| chuẩn bị mở PR / release | cả bốn |

Khi chạy: `typecheck` · `lint` · `lint:boundaries` độc lập nhau → phát **3 tool call Bash song song
trong cùng một message**, đừng nối `&&`. Full suite cần **timeout ≥ 25 phút**.

⚠ **CI không gánh hộ** — `deploy/.github/workflows/build-deploy.yml` chỉ dựng bundle, không
typecheck/lint/test.

## 4. Luật đỏ — so với baseline, không so với "xanh tuyệt đối"

Nền 2026-08-13: `typecheck` 192 lỗi · `lint` 9 lỗi + 2 warning · `lint:boundaries` 76 lỗi ·
full suite 16 test đỏ / 370 file.

- **Đỏ trong phạm vi vừa code → phải sửa**, không được báo hoàn thành.
- **Đỏ ngoài phạm vi** → xác minh là đỏ sẵn (chạy lại file đó trên nhánh gốc / `git stash`), rồi
  **liệt kê là nợ có sẵn**, không tự sửa.
- `tsc -b` đỏ với `TS6053: File ... not found` = **`tsbuildinfo` cũ** trỏ tới file test đã xoá — xoá
  `client/tsconfig*.tsbuildinfo` rồi chạy lại, không phải lỗi code.
- **Xoá sạch file test debug tự sinh** (`__dbg.test.tsx`, `tmp*.test.ts`…) trước khi báo hoàn thành.
- **Không tắt lint rule, không thêm `eslint-disable`** để qua cổng. Cần ngoại lệ thật → hỏi user.
- Sửa không được → báo nguyên văn lỗi + lý do, không giấu.

**Cổng cây commit** (nếu có commit): `git add` file mới **TRƯỚC**, rồi mới sửa barrel/`index.ts` trỏ
tới nó; `git status` sạch (không còn `??` trong `client/src/`); `npm run check:committed`;
rename/move dùng `git mv`.

## 5. Nhật ký `IMPLEMENT.md`

Ghi trong **thư mục plan** (`docs/doing/<slug>-fe/IMPLEMENT.md`), không ghi vào `client/`:

1. **Ngày · phạm vi đã code** (file con nào của plan đã làm, cái nào chưa).
2. **Danh sách file đã tạo/sửa** — đường dẫn thật + một câu vai trò.
3. **Đã reuse gì** — component `@base`/`@domain-kit` dùng lại (`file:dòng`), và mỗi thứ viết mới kèm
   lý do không reuse được.
4. **Lệch so với plan** — lệch gì · vì sao · ảnh hưởng.
5. **Nợ kỹ thuật** — `mock.ts`, TODO, phần bỏ lại vì chờ BA/Design.
6. **Kết quả cổng** — output thật của ba lệnh mục 2, **liệt kê thẳng lệnh nặng nào chưa chạy**, và
   danh sách test đỏ có sẵn đã xác minh không do thay đổi lần này.
7. **BR đã áp dụng** và BR chưa đạt (kèm lý do).

## 6. Báo cáo khi xong

1. **Cây file đã sinh** — theo thư mục, kèm một câu vai trò mỗi file.
2. **Đã reuse gì / phải viết mới gì** (kèm lý do không reuse được).
3. **Lệch so với plan** — nêu ngay, không giấu ở cuối.
4. **Conflict Figma ↔ Matrix** đã xử lý thế nào, hoặc còn treo chờ ai.
5. **Phần chưa làm** — chờ BA/Design (Q…), chờ API BE, ngoài phạm vi — kèm lý do từng phần.
6. **Nợ kỹ thuật** — đặc biệt `mock.ts` còn lại.
7. **Kết quả cổng** — trạng thái thật của ba lệnh + danh sách lệnh nặng chưa chạy. **Cấm viết "đã qua
   cổng nghiệm thu" khi mới chạy cổng nhẹ.**
8. **BR đã áp dụng** và BR nào chưa đạt (kèm lý do).
9. Đường dẫn `IMPLEMENT.md`.
