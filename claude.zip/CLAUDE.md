# PMKT — Quy tắc bắt buộc cho AI & DEV

File này là **bản ràng buộc cứng**, áp cho mọi project trong repo. Chi tiết nằm ở file con —
chỉ mở khi thật sự cần, đừng đọc trước hết.

| Cần gì | Mở file nào |
|---|---|
| Quy ước code đầy đủ | [docs/rules/conventions.md](docs/rules/conventions.md) |
| Khung 1 phiếu yêu cầu — BE | [docs/rules/be-khung-kien-truc-chuan.md](docs/rules/be-khung-kien-truc-chuan.md) · [cell-app/CLAUDE.md](cell-app/CLAUDE.md) |
| Khung 1 phiếu yêu cầu — FE | [docs/rules/fe-khung-kien-truc-chuan.md](docs/rules/fe-khung-kien-truc-chuan.md) · [client/CLAUDE.md](client/CLAUDE.md) |
| Quy chuẩn nghiệp vụ BR | `./docs/rules/br.sh <số BR>` — **xem §BR bên dưới** |

## Cấu trúc repo

| Thư mục | Loại | Ghi chú |
|---|---|---|
| `client/` | Frontend | React 19 + TS strict + Vite + Ant Design + i18next |
| `cell-app/`, `cell-gateway/`, `front-door/`, `identity/`, `integration-platform/`, `shared-kernel/`, `tenant-provisioning/` | Backend | Java 21 + Spring Boot + Gradle KTS, base package **`vn.vtt.pmkt`** |
| `notification/`, `audit-logs-service/` | Backend | Java 21 + Spring Boot, base package **`vn.dopai.pmkt`** — **KHÁC** 7 service trên, chưa đổi tên theo |

⚠ **Base package KHÔNG đồng nhất toàn repo.** `cell-app` từng đổi `vn.dopai.pmkt` → `vn.vtt.pmkt`
(commit `1266deb0`) và 6 service cùng đợt đổi theo; `notification/` và `audit-logs-service/` **chưa
đổi**, vẫn là `vn.dopai.pmkt`. Sinh code thì lấy package theo **service đang sửa**, đừng suy từ service khác.

Mỗi service là **một git repo riêng**; repo gốc `vtt-osp/` KHÔNG phải git repo và KHÔNG có `gradlew`.

## BR — quy chuẩn nghiệp vụ dùng chung (BẮT BUỘC)

Nguồn: `pmkt-docs/ba/Common/business_rules.md` (**BR1…BR49**, ~183 KB — **KHÔNG đọc cả file**).

```bash
./docs/rules/br.sh --list        # mục lục BR (~2 KB)
./docs/rules/br.sh 7 30 39       # in đúng BR7, BR30, BR39
```

Quy trình bắt buộc trước khi code:

1. Tra bảng dưới → chạy `br.sh` với đúng các số BR trong phạm vi. Không code theo trí nhớ.
2. Epic/BA chỉ mô tả phần **đặc thù**; phần chung mặc định lấy theo BR. Epic không nhắc lại BR
   **không** có nghĩa được bỏ qua BR.
3. **Xung đột**: epic thắng trong đúng phạm vi epic đó, và phải **báo rõ đang lệch BR nào**.
4. **Thiếu quy định**: BR chưa phủ → **hỏi user**, không tự đặt luật mới.
5. Khi báo hoàn thành: **liệt kê BR đã áp dụng** và mục nào chưa đạt (kèm lý do).

| Phạm vi công việc | BR phải đọc |
|---|---|
| Màn danh sách (grid) | 1 2 11 13.1 30 31 32 38 39 44 45 |
| Danh mục dạng cây | 2 22 23 40 |
| Form nhập liệu / popup | 3 13.2 14 15 24 34 43 |
| Combogrid / chọn dữ liệu | 5 6 10 |
| Chứng từ & hạch toán | 4 9 12 17 33 36 37 41 42 48 49 |
| Số liệu / tiền tệ | 7 18 |
| Ngày tháng / kỳ báo cáo | 8 |
| Thông báo & cảnh báo | 16 26 27 |
| Entity / DB / API | 7 19 20 28 29 46 |
| Danh mục — dữ liệu mặc định | 23 47 |
| Quyền | 25 |
| Grid chi tiết con | 21 |
| Điều hướng giữ ngữ cảnh | 35 |

Text hiển thị theo BR (message lỗi, cảnh báo, placeholder…) vẫn phải qua i18n theo **luật 2** —
giữ **nguyên văn tiếng Việt** của BR làm giá trị trong `vi.ts`, không tự diễn đạt lại.

## 8 luật không được vi phạm

1. **Không hardcode** magic value — mọi số/chuỗi nghiệp vụ phải là constant có tên, đặt gần nơi dùng nhất.
2. **Không hardcode text UI** — mọi chuỗi người dùng thấy phải có key i18n ở **cả** `vi.ts` và `en.ts`. Chuỗi động dùng `t('key', { name })`, không cộng chuỗi.
3. **Không `any`, không `@ts-ignore`** (FE) — dùng `unknown` + type guard, hoặc Zod parse cho dữ liệu ngoài.
4. **Import bằng path alias** (FE: `@core`, `@base`, `@platform`, `@domain-kit`, `@features/*`, `@app/*`) — không `../../`. Import chỉ đi xuống tầng dưới.
5. **Phân tầng BE**: `Controller → Service → Repository → Entity`. Controller không chứa business logic, không gọi Repository, không trả Entity ra ngoài.
6. **API chuẩn**: mọi response bọc `ApiResponse<T>`; lỗi xử lý tập trung bằng `@RestControllerAdvice`.
7. **Không commit secret** — dùng env / `application.yml` / `@ConfigurationProperties`.
8. **Commit & branch đúng chuẩn**: `<type>(<scope>): <mô tả>` và `loại-nhánh/tên-mo-ta`. Không commit thẳng vào `master`/`develop`.

## Cấu trúc module Backend (`cell-app`) — BẮT BUỘC

`cell-app` là **Spring Modulith**: mỗi thư mục cấp 1 dưới `cell/` là một application module.

```
cell/<module>/
├── package-info.java          BẮT BUỘC: @ApplicationModule(displayName = "<module>")
├── api/                       CHỈ tạo khi module KHÁC thật sự cần gọi vào
│   ├── package-info.java        @NamedInterface("<tên>") — thiếu là Modulith chặn
│   └── dto/
└── internal/                  mặc định MỌI thứ nằm ở đây
    ├── controller/            @RestController — để package-private
    ├── dto/ entity/ model/ port/ repository/
    └── service/business/      template · mapper · validator · tính toán
```

1. **Mặc định là `internal/`** — không tạo `api/` "cho chắc". `chung_tu_ban_hang/` (module chứng từ đầy đủ nhất repo) không có `api/` nào.
2. **`api/` phải có `package-info.java` khai `@NamedInterface`** — lộ `x.api` KHÔNG tự động lộ `x.api.dto`; mỗi package con khai riêng.
3. **Không đổ file phẳng ra gốc module.** Shape `controller/ dto/ entity/…` ở gốc (không có `internal/`) là shape cũ đã đóng băng.

Module lớn: chia sub-module trước rồi mới `api/ internal/` → `<module>/<sub>/api|internal/`.
**Đừng viết lại khung** — `cell/core/` đã cấp `BaseCrudController` (8 endpoint), `BaseCrudService`,
`ApiResponse<T>`, `QuyenChecker`, tìm kiếm động qua `@Searchable`; chứng từ kế toán đi qua
`accounting_core.chung_tu.ChungTuTemplate`, ghi sổ chỉ qua `hach_toan.api.GhiSoApi`.

Mẫu đúng: `chung_tu_ban_hang/`, `accounting_core/`, `integration_ops/`.

## Cấu trúc module Frontend — BẮT BUỘC

**MỘT màn hình = MỘT module phẳng** trong `client/src/features/`.

```
features/<domain>/
├── routes.tsx                 route contribution (eager → phải mỏng)
└── <module>/
    ├── index.ts               FILE DUY NHẤT ở gốc module
    ├── api/                   I/O + Zod với BE
    ├── components/            MỌI .tsx — list · tab · popup Thêm/Sửa/Xem · panel con
    ├── constants/             constants.ts · paths.ts · permissions.ts
    ├── fields/                cột · ô lưới · option · badge · texts + types.ts
    ├── helpers/               hàm thuần biết nghiệp vụ (không React, không mạng, không t())
    ├── hooks/                 state / effect / request
    ├── i18n/                  vi.ts · en.ts · registerXxxI18n.ts — MỘT namespace
    ├── pages/                 <Tên>Page.tsx (chỉ ráp) + <tên>.css
    └── test/                  mọi test
```

1. **Gốc module chỉ có `index.ts`** — không `Page.tsx`, `types.ts`, `constants.ts`, `.css`, `paths.ts`, `permissions.ts` ở gốc.
2. **Không tách màn theo hành vi** (`danhSach/` · `themMoi/` · `chinhSua/`). Popup Thêm/Sửa/Xem là component cùng module → `components/`. `_shared/` chỉ tạo khi domain đã có ≥2 module thật.
3. **Không `../../` trong module** — cây phẳng một bậc, `../../` = đặt file sai chỗ.

Mẫu tham chiếu **duy nhất**: `client/src/features/banHang/chungTuBanHang/`.

## Vùng đóng băng — KHÔNG đọc, KHÔNG tham khảo

`cell-app/src/main/java/vn/vtt/pmkt/cell/master_data/**` và `client/src/legacy/**`: kiến trúc lỗi thời,
không phát triển tiếp. KHÔNG đọc để "xem dự án đang làm thế nào", KHÔNG sao chép pattern, KHÔNG dùng làm
mẫu, và khi grep/glob toàn repo thì **bỏ qua** kết quả rơi vào đây.

Rule này còn chặn cứng ở [.claude/settings.json](.claude/settings.json) (`permissions.deny`).

**Ngoại lệ duy nhất** — user yêu cầu trực tiếp sửa `master_data`, hoặc module khác lỗi biên dịch vì API
công khai của nó: đọc **đúng** chữ ký cần dùng, không lấy kiến trúc, **báo rõ cho user** là đang chạm vùng
đóng băng, và **xin phép** trước khi gỡ tạm rule deny.

## CLAUDE.md con — BẮT BUỘC đọc trước khi sửa code trong thư mục đó

Đã có ở: `client/`, `cell-app/`, `cell-gateway/`, `front-door/`, `identity/`, `integration-platform/`,
`shared-kernel/`, `tenant-provisioning/`, `pmkt-docs/` — và có thể phát sinh ở thư mục con sâu hơn.

Rule áp dụng **cộng dồn** (gốc + con). **Xung đột**: rule con (gần thư mục đang sửa hơn) **ghi đè** rule gốc
trong đúng phạm vi đó; không chắc phạm vi thì **hỏi user**. **Không suy diễn** nội dung file con nếu chưa đọc.

## CHẠY CODE — QUA INTELLIJ, TUYỆT ĐỐI KHÔNG DOCKER

Máy này **không có Docker** và **không được cài thêm**. Không `docker`/`docker compose`/`podman`/`colima`,
không `deploy/docker-compose*.yml`, không tự bật container phụ trợ (Postgres, Redis, MinIO…).

- Chạy service / test: `mcp__idea__get_run_configurations` → `mcp__idea__execute_run_configuration`
- Build qua IDE: `mcp__idea__build_project` · lỗi trên 1 file: `mcp__idea__get_file_problems` / `lint_files`
- SQL: `mcp__idea__execute_sql_query` · `list_schema_objects` (datasource đã cấu hình trong IDE)
- Luôn truyền `projectPath` — IntelliJ đang mở cả repo gốc `vtt-osp/`.
- **Frontend**: dev server qua Browser pane (`preview_start`), không `npm run dev` trong Bash nền.
  Cổng 5173 thường đã có server của user — dùng lại, đừng dựng thêm.
- **Test Testcontainers thì KHÔNG chạy** (bắt buộc Docker). Dùng `./gradlew unitTest` hoặc chạy đúng test
  class qua IntelliJ, rồi **nói rõ** phần Testcontainers chưa chạy.
- Cần thứ chỉ Docker mới làm được → **dừng và hỏi user**, không tự tìm đường vòng.

## Trước khi báo hoàn thành — BẮT BUỘC chạy

```bash
# nếu chạm client/  — dùng đường dẫn tuyệt đối, cwd hay bị reset về gốc repo
cd client && npm run typecheck && npm run lint && npm run lint:boundaries && npm run test && npm run build
cd client && npm run check:committed    # BẮT BUỘC nếu có commit
```

```bash
# nếu chạm cell-app/ — LÀ GRADLE PROJECT ĐỘC LẬP
cd cell-app && ./gradlew unitTest       # CỔNG CHÍNH: chỉ @Tag("unit"), ~1 phút, không cần Docker
```

⚠ `./gradlew :cell-app:build` ở gốc repo **luôn báo "no such file or directory"** — không có
`settings.gradle.kts` ở gốc. ⚠ `./gradlew build` **không** còn là cổng nghiệm thu — nó kéo ~25 test
Testcontainers (cần Docker, đã bị cấm). Cổng xanh thực tế là `unitTest`.

Rồi soát [Checklist §5](docs/rules/conventions.md#5-checklist-trước-khi-commit), đối chiếu lại BR trong phạm vi
vừa làm, và **báo trung thực** mục nào chưa đạt.

### Cổng cây commit — file mới phải được `git add`

Mọi lệnh trên chạy trên **working tree**; CI thì `git reset --hard origin/<branch>` rồi build trên **cây
commit**. File mới quên `git add` → **xanh 100% local, đỏ 100% deploy**:

```
[UNRESOLVED_IMPORT] Could not resolve './components/fields/CommonTimeInput' in src/base/index.ts
```

1. **`git add` file mới TRƯỚC, rồi mới sửa barrel/`index.ts`/import trỏ tới nó.**
2. **`git status` phải sạch** trước khi báo hoàn thành hoặc push. Còn dòng `??` trong `src/` (FE) hay
   `src/main/java/` (BE) là còn nguy cơ.
3. **FE: chạy `npm run check:committed`** sau khi commit (~0,7 giây). Kiểm nhánh đã đẩy:
   `npm run check:committed -- origin/<branch>`.
4. **Không rename/move bằng `mv` trần** — dùng `git mv`.

Chi tiết: [client/CLAUDE.md §15.1](client/CLAUDE.md).

## Quy ước đặt tên (tóm tắt)

**FE** — `.tsx` PascalCase · `.ts` camelCase · thư mục camelCase · constant SCREAMING_SNAKE_CASE ·
hook `useXxx` · prop `onXxx` / handler `handleXxx` · ưu tiên named export.

**Java** — Class/Interface/Enum/Record PascalCase · package chữ thường (`snake_case` khi cần) ·
method/variable camelCase · constant SCREAMING_SNAKE_CASE + `static final` · bảng/cột DB snake_case ·
DTO hậu tố `…Request` / `…Response` / `…Dto` · constructor injection với `@RequiredArgsConstructor`.

## Khi gặp code cũ vi phạm quy tắc

Code mới tuân thủ 100%. Code cũ chỉ dọn **trong phạm vi đang sửa** — không refactor hàng loạt, không mở
rộng diff. Vi phạm diện rộng thì báo lại để mở ticket riêng.
