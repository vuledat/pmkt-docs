# Đọc bắt buộc trước khi code — `/gen-fe` bước 1

Đọc file này TRƯỚC khi gõ dòng code đầu tiên. Không đọc lướt.

## Chốt đầu vào — không đoán

1. Không có đường dẫn → hỏi lại, **không đoán**, không tự tìm epic gần nhất.
2. **Chưa có plan FE** (user chỉ đưa PYC): báo user rằng chuẩn là chạy `/plan-fe` trước, và hỏi:
   chạy `/plan-fe` trước rồi code, hay code thẳng từ PYC. User chọn code thẳng → vẫn phải làm
   **đủ §1 và §2 của `/plan-fe`** (đọc bắt buộc + khảo sát có bằng chứng) trước khi code, và ghi kết
   quả khảo sát vào `IMPLEMENT.md`.
3. Plan có mục **§12 "Điểm cần BA/Design xác nhận" (Q1…Qn) chưa được trả lời** → **không code phần
   phụ thuộc câu hỏi đó**. Làm hết phần còn lại, liệt kê phần bỏ lại và lý do trong báo cáo. Chỉ dừng
   toàn bộ khi Q chặn phần lớn màn hình.
4. Module đích đã tồn tại trong `client/src/features/` → **đọc hết module đó trước**, rồi làm theo
   kiểu "bổ sung vào cây có sẵn", không tạo module trùng, không âm thầm ghi đè file có sẵn.
5. Thư mục đích khác plan đề xuất → theo user.

## Kế hoạch

Toàn bộ file trong thư mục plan — `00-ke-hoach-tong.md`, mọi `NN-<man-hinh>.md`,
`NN-hop-dong-api-va-i18n.md`. §3 reuse, §4 cây thư mục, §7 bản đồ màn, §8 i18n là **ràng buộc cứng**
cho code.

## Rule & khung

- `CLAUDE.md` (gốc) + `client/CLAUDE.md` (đặc biệt §5 cấu trúc module, §13 test, §15.1 cổng cây commit)
- `docs/rules/fe-khung-kien-truc-chuan.md` — **SSOT cấu trúc module**: cây thư mục, 5 hệ quả, cây
  quyết định §3.2 (việc nào vào file nào), 4 câu hỏi bắt buộc §4, checklist artefact §5, code mẫu §6
- `docs/rules/conventions-chung.md` + `docs/rules/conventions-fe.md` — **KHÔNG** đọc `conventions.md` (đã tách; phần Java không liên quan)
- BR trong phạm vi: tra bảng ở `CLAUDE.md` rồi chạy `./docs/rules/br.sh <số BR>` (vd `./docs/rules/br.sh 7 30 39`). **KHÔNG đọc cả `business_rules.md`** — file nặng ~183 KB.

## Tài liệu PYC

**Bước 0 — liệt kê thư mục PYC trước khi đọc**, đừng đoán tên (đa số epic dùng `5.screens/`
nhưng có epic dùng `4.screens/` hoặc `6.screens/`):

```bash
ls <thư-mục-PYC>/ && ls <thư-mục-PYC>/Matrix/
```

`Matrix/**` (đọc trước tiên) · `5.screens/**` (`SCR_*.md`) · `6.messages.md` (**nguyên văn** → giá trị
`vi.ts`) · `4.usecases/**` · `1.function-breakdown.md` · `3.crud-matrix.md` (nếu có).

⚠ Đặc tả màn có thể **rất lớn** (`SCR_CTBH_ThemMoi.md` = 187 KB). Chỉ đọc file `SCR_*` của **đúng màn
đang code**, không đọc cả `5.screens/`.

## Figma (nếu có link)

Đọc qua Figma MCP — `get_design_context`, `get_screenshot`, `get_variable_defs`, `get_metadata`.
**Không đoán số đo.** Không có số thật → dùng token/biến có sẵn của hệ thống, ghi vào `IMPLEMENT.md`
là điểm cần Design xác nhận.

## Code base phải reuse tối đa (khảo sát thật trước khi viết mới)

- Mẫu tham chiếu **duy nhất**: `client/src/features/banHang/chungTuBanHang/`
- `client/src/base/index.ts` — ~219 component đã export qua `@base`
- `@domain-kit/catalog` · `@domain-kit/chungTu` · `@domain-kit/report` — có engine thì **dùng
  descriptor, không viết lại khung**
- `@core`, `@platform` — tiện ích kỹ thuật thuần
- `client/src/app/router/RootRoutes.tsx`

**Vùng cấm:** `client/src/legacy/**` — KHÔNG đọc để tham khảo, KHÔNG lấy làm mẫu, KHÔNG mở màn mới ở đó.
