---
name: push-code
description: Commit và push code đúng chuẩn Git của PMKT cho MỘT thư mục repo. Dùng khi user gõ /push-code <thư mục> (ví dụ /push-code client, /push-code cell-app) hoặc yêu cầu "commit và push", "đẩy code lên", "tạo commit chuẩn". CHỈ commit + push: không chạy lint/test/build, chỉ soát secret và không bao giờ commit thẳng vào master/develop.
---

# /push-code — Commit & push đúng chuẩn

**Đầu vào bắt buộc:** thư mục repo (`client`, `cell-app`, `front-door`, `identity`, `cell-gateway`,
`integration-platform`, `shared-kernel`, `tenant-provisioning`, `pmkt-docs`). Không có → **hỏi lại**,
không đoán.

**Đầu ra:** commit `<type>(<scope>): <mô tả>` trên nhánh hợp lệ, đã push lên `origin`, kèm báo cáo
trung thực + link tạo PR.

Chuẩn Git đầy đủ: `docs/rules/conventions-chung.md §4`. Cổng cây commit: `client/CLAUDE.md §15.1`.

## 1. Chốt phạm vi

- Gốc `vtt-osp/` **không phải** git repo; mỗi service là repo riêng
  (`github.com/ospgroupvn-pmkt/<repo>`). Xác định git root bằng `git -C <thư mục> rev-parse
  --show-toplevel` và **báo lại git root đã chọn**.
- **Một lần chạy = một repo.** Thay đổi ở nhiều repo → nói rõ, hỏi làm cái nào trước.
- Working tree có thay đổi lạ không do phiên này sinh ra → **liệt kê cho user quyết**, không cuốn vào
  commit.

Khảo sát: `git status --short --branch` · `git diff --stat` · `--staged` · `git log --oneline -8`
(đọc log để bắt chước phong cách commit **của chính repo đó**).

## 2. KHÔNG chạy cổng kiểm tra

**Không** `typecheck`, `lint`, `test`, `build`, `./gradlew` — dù diff to, dù code khả nghi. Chất
lượng là việc của `/gen-fe` và CI. Thấy lỗi rõ ràng → **nói cho user**, không tự sửa để "cho xanh",
rồi push nguyên trạng nếu user không yêu cầu sửa.

## 3. Soát secret & file rác — một lượt grep, không review từng hunk

Chỉ hai thứ **không rút lại được sau khi push**:

1. Secret trong `git diff` + `--staged` + nội dung file untracked — grep: `password` · `secret` ·
   `api[_-]?key` · `token=` · `bearer` · `BEGIN .*PRIVATE KEY` · `jdbc:` · `postgres://`
2. File không nên vào repo: `git status --porcelain -uall | grep -iE '\.env|\.p12|\.jks|\.pem|node_modules/|/dist/|/build/|\.tsbuildinfo|\.zip'`

Có secret → **dừng, không commit**, báo user; đã lỡ commit thì **rotate key**, không chỉ xoá commit.
File rác → loại khỏi `git add`, báo một dòng. Ngoài hai thứ này **không phán xét chất lượng code**.

## 4. Nhánh

`master` · `develop` · `main` **cấm commit trực tiếp** → đang đứng đó mà có thay đổi thì **dừng, hỏi
user**, đề xuất `loại-nhánh/tên-mo-ta` (chữ thường, nối `-`): `feat/` `bugfix/` (**không** `fix/`)
`hotfix/` `refactor/` `chore/` `docs/` `release/`. Tách từ `develop`, riêng `hotfix/*` từ `master`.
**Không tự đổi nhánh** khi đang có thay đổi chưa commit.

## 5. `git add` — cổng cây commit

CI `git reset --hard origin/<branch>` rồi build trên **cây commit**, nên file quên `git add` làm CI đỏ
dù local xanh (sự cố thật: `[UNRESOLVED_IMPORT] Could not resolve './components/fields/CommonTimeInput'`).

1. **File mới `git add` TRƯỚC**, rồi mới commit barrel/`index.ts` trỏ tới nó.
2. **Không `git add -A` / `git add .` mù** — add từng đường dẫn, liệt kê danh sách cho user thấy.
3. Rename/move dùng **`git mv`**, không `mv` trần.
4. Sau khi add: không còn `??` trong `src/` (FE) hay `src/main/java/` (BE) thuộc phạm vi.

## 6. Commit

`<type>(<scope>): <mô tả ngắn, thể mệnh lệnh>` — type ∈ `feat` `fix` `docs` `style` `refactor` `perf`
`test` `chore`; scope là module/domain.

```
✅ feat(chungTuBanHang): thêm popup chọn khách hàng theo Matrix ẩn/hiện
❌ update code    ❌ fix bug    ❌ wip
```

**1 commit = 1 ý nghĩa** — diff trộn `feat` + `refactor` + format lại → **tách nhiều commit**, xếp
theo thứ tự phụ thuộc (module nền trước, module cắm vào sau). Migration DB đi **cùng commit** với code
dùng nó. Thân commit nêu *vì sao*, không kể lại đã sửa file nào. Kết thúc bằng:

```
Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
```

Sau commit: `git status --short` (sạch phần thuộc phạm vi) + `git show --stat HEAD`. **Không** chạy
`check:committed`/`typecheck`/`test`/`build` — xem §2.

## 7. Push

```bash
git -C <repo> push -u origin <ten-nhanh>
```

- **Xác nhận với user trước** khi push nhánh mới, hoặc khi remote đã có commit của người khác
  (`git fetch` rồi so `@{u}..HEAD` và ngược lại).
- **Không bao giờ** `push --force` / `--force-with-lease` lên nhánh chung.
- **Không push vào `master`/`develop`/`main`.**
- Bị từ chối vì remote đi trước → **dừng, báo user**, không tự `rebase`/`merge`/ép.

## 8. Báo cáo

1. Repo + git root + nhánh (nhánh mới thì nói tách từ đâu).
2. **Nhắc rõ chưa chạy cổng nào** — lint/test/build không chạy (§2).
3. File đã commit · file **cố ý không commit** (kèm lý do).
4. Từng commit: hash ngắn + message.
5. Trạng thái push + link PR: `https://github.com/ospgroupvn-pmkt/<repo>/compare/<ten-nhanh>?expand=1`
6. Việc còn lại cho user (mở PR, gán reviewer, repo thứ hai chưa push, secret cần rotate…).
