# Cổng nghiệm thu + báo cáo — `/gen-be`

Đọc ở **bước cuối**, trước khi báo hoàn thành. `<REPO>` = đường dẫn tuyệt đối tới gốc repo của phiên.

## 1. Cổng — KHÔNG Docker, chạy qua IntelliJ khi cần sâu hơn

`cell-app` là Gradle project **độc lập** (wrapper riêng); `./gradlew :cell-app:build` ở gốc repo
**luôn** báo "no such file or directory".

```bash
cd <REPO>/cell-app && ./gradlew unitTest    # CỔNG CHÍNH — chỉ @Tag("unit"), thuần JVM, ~1 phút
```

🚫 **KHÔNG `./gradlew build`, KHÔNG `./gradlew test`, KHÔNG Docker** — chúng kéo ~25 test
Testcontainers và bắt buộc có Docker, thứ bị cấm tuyệt đối (`CLAUDE.md` mục "CHẠY CODE — QUA
INTELLIJ, TUYỆT ĐỐI KHÔNG DOCKER").

Cần sâu hơn `unitTest`:

- `mcp__idea__build_project` — compile qua IDE
- `mcp__idea__get_run_configurations` + `mcp__idea__execute_run_configuration` — chạy đúng test class
  hoặc boot service
- `mcp__idea__get_file_problems` / `lint_files` — lỗi trên một file, không phải chạy cả Gradle
- `mcp__idea__execute_sql_query` / `list_schema_objects` — kiểm migration trên datasource đã cấu hình
  trong IDE, **không** dựng DB bằng container

Luôn truyền `projectPath` vì IntelliJ đang mở cả repo gốc `vtt-osp/`.

## 2. Luật đỏ

- **Đỏ trong phạm vi vừa code → phải sửa.** Không báo hoàn thành khi còn đỏ.
- **Đỏ ngoài phạm vi** → xác minh là đỏ sẵn (chạy lại trên nhánh gốc / `git stash`), liệt kê là **nợ
  có sẵn**, không tự sửa.
- **Test Testcontainers không chạy được** = phải nói thẳng trong báo cáo, không ngầm bỏ qua.
- `ApplicationModules.verify()` **không** chạy trần được — `cell-app` còn ~96 vi phạm ranh giới có sẵn;
  kiểm ranh giới bằng test có lọc như `arch/ProxyModularityTest` (`viPhamCoNhacToi("<module>")`).
- Sửa không được → báo nguyên văn lỗi + lý do, không giấu, không nới rule cho xanh.

## 3. Cổng cây commit

`git add` file mới **TRƯỚC**, rồi mới commit thứ trỏ tới nó. `git status` phải sạch (không còn `??`
trong `src/main/java/`, `src/test/java/`, `src/main/resources/db/migration/`). Rename/move dùng
`git mv`. Migration đi **cùng commit** với code dùng nó.

## 4. Nhật ký `IMPLEMENT.md`

Ghi trong **thư mục plan** (`docs/doing/<slug>-api/IMPLEMENT.md`), không ghi vào `cell-app/`:

1. **Ngày · phạm vi đã code** (file con nào của plan đã làm, cái nào chưa).
2. **Danh sách file đã tạo/sửa** — đường dẫn thật + một câu vai trò.
3. **Đã kế thừa gì từ base** (`file:dòng`), và mỗi thứ viết mới kèm lý do không kế thừa được.
4. **Migration đã thêm** — số hiệu `V…`, bảng/cột đụng tới, đã chạy chưa và chạy trên DB nào.
5. **Lệch so với plan** — lệch gì · vì sao · ảnh hưởng.
6. **Nợ kỹ thuật** — endpoint trả `CHUA_HO_TRO`, TODO, phần chờ BA.
7. **Kết quả cổng** — output thật `./gradlew unitTest`; **ghi rõ phần Testcontainers chưa chạy**.
8. **File Postman** — đường dẫn `docs/json/<slug>.postman_collection.json`, số nhóm/số request, lấy
   từ app đang chạy hay dựng từ plan.
9. **BR đã áp dụng** và BR chưa đạt (kèm lý do).

## 5. Báo cáo khi xong

1. **Cây file đã sinh** — theo module, kèm một câu vai trò mỗi file.
2. **Danh mục endpoint đã làm** — bảng: method · path · quyền · trạng thái (xong / chưa hỗ trợ).
3. **Đã kế thừa gì / phải viết mới gì** (kèm lý do).
4. **Migration** — số hiệu, đã chạy chưa, cần seed quyền không (BR25).
5. **Lệch so với plan** — nêu ngay, không giấu ở cuối.
6. **Phần chưa làm** — chờ BA (Q…), ngoài phạm vi — kèm lý do từng phần.
7. **Kết quả cổng** — `unitTest` thật; **nói thẳng** Testcontainers chưa chạy vì cấm Docker.
8. **Đường dẫn file Postman** trong `docs/json/` + cách import.
9. **BR đã áp dụng** và BR nào chưa đạt.
10. Đường dẫn `IMPLEMENT.md`.
