---
name: gen-fe
description: Sinh code màn hình frontend (client/) từ kế hoạch FE đã review. Dùng khi user gõ /gen-fe <đường dẫn thư mục plan trong docs/doing/*-fe/ hoặc thư mục PYC trong pmkt-docs/ba/> [link Figma] hoặc yêu cầu "code màn hình / gen FE / triển khai plan FE" cho một epic PMKT-E-xxxxx. Skill này SINH CODE THẬT trong client/src/features/, khác với /plan-fe (chỉ sinh .md).
---

# /gen-fe — Sinh code màn hình FE từ kế hoạch

**Đầu vào:** (1) thư mục plan FE do `/plan-fe` sinh, ví dụ `docs/doing/PMKT-E-07528-khoa-so-fe` —
**ưu tiên số 1**; user đưa thẳng thư mục PYC mà chưa có plan → xử lý theo `references/doc-bat-buoc.md`
mục "Chốt đầu vào" (báo user nên chạy `/plan-fe` trước, và hỏi). (2) link Figma — tuỳ chọn nhưng rất
nên có. (3) phạm vi hẹp tuỳ chọn: `/gen-fe <plan> 01,02`.

**Đầu ra:** code thật trong `client/src/features/<domain>/<module>/`, **cộng** `routes.tsx` +
`RootRoutes.tsx`, **cộng** test trong `test/`, **cộng** `IMPLEMENT.md` trong thư mục plan.

**Hai nguồn sự thật:** Figma = UI (layout, spacing, typography, màu, kích thước, trạng thái) ·
Matrix + UC = behavior (ẩn/hiện, required, disabled, nghiệp vụ). Conflict → **behavior theo Matrix,
UI theo Figma**, và **dừng hỏi user** trước khi code phần đang conflict.

Mọi luật đọc tài liệu / reuse / BR / i18n của `/plan-fe` **áp dụng nguyên vẹn**, chỉ đổi đầu ra từ
`.md` sang `.tsx/.ts/.css`.

---

## Ba file tham chiếu — đọc đúng lúc, không đọc trước hết

| Khi nào | Đọc |
|---|---|
| **Trước dòng code đầu tiên** | `references/doc-bat-buoc.md` — chốt đầu vào · tài liệu bắt buộc · Figma · khảo sát reuse |
| **Trong lúc sinh code** | `references/luat-code.md` — reuse · type · i18n · phạm vi · luật viết test · nợ kỹ thuật |
| **Trước khi báo hoàn thành** | `references/cong-va-bao-cao.md` — cổng nhẹ · lệnh nặng · luật đỏ · `IMPLEMENT.md` · mẫu báo cáo |

---

## Ba luật cứng về cấu trúc (không được vi phạm, không cần mở file khác)

1. **Gốc module chỉ có `index.ts`.** Không `Page.tsx`, `types.ts`, `constants.ts`, `.css`,
   `paths.ts`, `permissions.ts` ở gốc.
2. **Một màn hình = một module phẳng.** Không tách theo hành vi (`danhSach/`, `themMoi/`,
   `chinhSua/`). Popup là component cùng module → `components/modal/`. `_shared/` chỉ tạo khi domain
   đã có ≥2 module thật.
3. **Không `../../` trong module.** Ngoài module dùng alias `@core`, `@base`, `@platform`,
   `@domain-kit`, `@features/*`, `@app/*`. Import chỉ đi xuống tầng dưới.

Mẫu tham chiếu **duy nhất**: `client/src/features/banHang/chungTuBanHang/`.
Vùng cấm: `client/src/legacy/**`.

---

## Trình tự sinh code — theo đúng thứ tự này

Sinh theo lát cắt dọc để mỗi bước đều compile được, **không** đổ hết file rỗng ra trước.

| Bước | Sinh gì | Ghi chú |
|---|---|---|
| 1 | `i18n/vi.ts` · `en.ts` · `register<Xxx>I18n.ts` | **một namespace cho cả module**; `vi` lấy **nguyên văn** `6.messages.md`/BR; popup là nhánh con (`themMoi.*`) |
| 2 | `constants/constants.ts` · `paths.ts` · `permissions.ts` | magic value → constant SCREAMING_SNAKE_CASE; mã quyền theo BR25 |
| 3 | `api/` — model Zod + hàm gọi + query key | đúng `NN-hop-dong-api-va-i18n.md`; response bọc `ApiResponse<T>` |
| 4 | `fields/types.ts` rồi `fields/` (cột · ô lưới · option · badge · texts) | precision theo BR7; ẩn/hiện cột mặc định BR30 |
| 5 | `helpers/` — hàm thuần, gồm `anHien.ts` dịch từ Ma trận | không React, không mạng, không `t()` |
| 6 | `hooks/` — state / effect / request | |
| 7 | `components/` — list · tab · panel; popup vào `components/modal/` | |
| 8 | `pages/<Tên>Page.tsx` (**chỉ ráp**) + `pages/<tên>.css` | Page không chứa business logic |
| 9 | `index.ts` ở gốc module | file duy nhất ở gốc |
| 10 | `features/<domain>/routes.tsx` + nối tay `app/router/RootRoutes.tsx` | handle DATA-ONLY (`perm`, `crumbKeys`); eager → phải mỏng |
| 11 | `test/` — case theo §10 mỗi file con của plan | docblock `// @vitest-environment node` cho test logic thuần |

**Giữa chừng** (sau nhóm bước 3 và 7): chỉ chạy test của **module đích**, không full suite, không
`npm run typecheck`. Lệnh cụ thể ở `references/cong-va-bao-cao.md`.
