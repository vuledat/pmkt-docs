# Đọc bắt buộc + khảo sát — `/plan-fe` bước 1–2

## Đọc bắt buộc trước khi viết (không được bỏ)

**Rule & khung:**
- `CLAUDE.md` (gốc) + `client/CLAUDE.md` (đặc biệt §5 cấu trúc module, §13 test)
- `docs/rules/fe-khung-kien-truc-chuan.md` — cây thư mục module, 4 câu hỏi bắt buộc, checklist artefact,
  luật cứng, cổng nghiệm thu
- `docs/rules/conventions-chung.md` + `docs/rules/conventions-fe.md`
- BR trong phạm vi: tra bảng ở `CLAUDE.md` rồi chạy `./docs/rules/br.sh <số BR>` (vd `./docs/rules/br.sh 7 30 39`). **KHÔNG đọc cả `business_rules.md`** — file nặng ~183 KB.

**Tài liệu phiếu yêu cầu:**
- `Matrix/**` — **đọc TRƯỚC TIÊN**: ma trận ẩn/hiện, required, disabled theo trạng thái + `_scope.md`
- `5.screens/**` — `SCR_*.md`, mỗi màn/popup một file (**liệt kê `ls` trước**: vài epic dùng `4.screens/`/`6.screens/`). File có thể tới 187 KB — chỉ đọc màn trong phạm vi phiếu
- `1.function-breakdown.md` ⇒ quyết định danh sách file con
- `4.usecases/**` (`UC_*.md` + `AD_*.puml`), `2.usecase.puml`
- `6.messages.md` — **nguyên văn** message, sẽ thành giá trị `vi.ts`

**Figma (nếu có link):** `mcp__figma__get_design_context` · `get_screenshot` · `get_variable_defs` ·
`get_metadata`. Lấy layout, spacing, typography, màu, kích thước, trạng thái. **Không đoán số đo.**

**Code base phải reuse tối đa** (khảo sát thật, ghi `file:dòng`):
- Module tham chiếu **duy nhất**: `client/src/features/banHang/chungTuBanHang/`
- `client/src/base/index.ts` — ~219 component / 21 họ đã export qua `@base`
- `@domain-kit/catalog` (danh mục) · `@domain-kit/chungTu` (chứng từ) · `@domain-kit/report` (báo cáo)
  — có engine thì **dùng descriptor, không viết lại khung**
- `@core`, `@platform` — tiện ích kỹ thuật thuần
- `client/src/app/router/RootRoutes.tsx` — kiểm màn/domain có đang chạy không

**Vùng cấm:** `client/src/legacy/**`.

## Khảo sát — bắt buộc có bằng chứng

Trả lời 4 câu hỏi bắt buộc của `docs/rules/fe-khung-kien-truc-chuan.md §4`, kèm bằng chứng:

| # | Câu hỏi | Cách trả lời |
|---|---|---|
| 0 | Code ở đâu? | luôn là `client/src/features/<domain>/<module>/` |
| 1 | Màn loại nào? | danh mục / chứng từ / báo cáo / khác ⇒ chọn domain-kit tương ứng |
| 2 | Đã có engine chưa? | grep descriptor trong `@domain-kit` |
| 3 | Component đã có ở `@base` chưa? | `grep -n "<tên>" client/src/base/index.ts` |
| 4 | Domain đang chạy không? | `grep -n "<domain>" client/src/app/router/RootRoutes.tsx` |

Thêm: **API BE đã có chưa?** — grep controller/endpoint trong `cell-app/`, hoặc trỏ về plan BE ở
`docs/doing/<slug>-api/`. Chưa có → nêu rõ là nợ (`mock.ts` tạm; còn `mock.ts` = còn nợ).

Ghi **lệnh đã chạy + kết quả thật** vào §2 file gốc.
