---
name: gen-flow-html
description: Sinh trang HTML sơ đồ luồng xử lý (mermaid) cho một phiếu yêu cầu BA rồi publish thành Artifact. Dùng khi user gõ /gen-flow-html <đường dẫn thư mục PYC trong pmkt-docs/ba/> hoặc yêu cầu "vẽ luồng xử lý / vẽ flow / sơ đồ luồng" cho một epic PMKT-E-xxxxx. Sinh 1 bản standalone + 1 bản nguồn artifact, KHÔNG code app.
---

# /gen-flow-html — Trang sơ đồ luồng xử lý từ tài liệu BA

**Đầu vào:** thư mục phiếu yêu cầu, ví dụ `pmkt-docs/ba/PMKT-E-06194_ChungTuBanHang` — bắt buộc.

**Đầu ra:** thư mục `docs/html/<PYC>/` gồm **hai** file, **một thẻ thêm vào trang tổng hợp**, kèm publish **Artifact**:

| File | Vai trò |
|---|---|
| `docs/html/<PYC>/<slug>-flow.html` | **Bản standalone** — `<!doctype>` + `<meta charset="utf-8">` + **SVG đã render sẵn**. Mở bằng double-click là đọc được, không cần mạng, không cần runtime mermaid |
| `docs/html/<PYC>/<slug>-flow.src.html` | **Bản nguồn để publish Artifact** — chỉ nội dung `<body>`, sơ đồ còn ở dạng `<pre class="mermaid">`. Artifact tự render mermaid và tự bọc `<head>` |
| `docs/html/tong_hop.html` | **Trang tra cứu chung** — thêm 1 thẻ cho epic vừa sinh (mục 5) |

**Không đảo vai trò hai file này.** Publish bản standalone lên Artifact là thừa `<html>/<head>`
(sai hợp đồng của tool); còn lưu bản `.src` vào `docs/` cho user mở trực tiếp thì **mất hết dấu
tiếng Việt** (thiếu `<meta charset>`) và **sơ đồ không hiện** (không có mermaid).

**Skill này KHÔNG code app.** Không đụng `client/`, `cell-app/`. Chỉ đọc `pmkt-docs/ba/**` và ghi
đúng một file `.html` + publish Artifact.

**Nguồn sự thật:** tài liệu BA trong thư mục PYC. Không suy diễn luồng không có trong UC/AD/BR;
thiếu thì ghi rõ là chưa có quy định, không tự đặt luật.

---

## Hai file tham chiếu — đọc đúng lúc

| Khi nào | Đọc |
|---|---|
| **Trước khi viết dòng HTML nào** | `references/khung-html.md` — khung trang · design token · chuỗi init mermaid · 6 bẫy kỹ thuật bắt buộc tránh |
| **Sau khi viết xong, trước khi publish** | `references/kiem-tra.md` — quy trình verify bằng Browser pane, ngưỡng đo, cách sửa từng lỗi |

---

## 0. Chốt đầu vào

1. Không có đường dẫn PYC → hỏi lại, **không đoán**.
2. `<PYC>` là **tên thư mục phiếu yêu cầu, giữ nguyên**: `PMKT-E-06194_ChungTuBanHang`.
   `<slug>` là dạng kebab của nó: `PMKT-E-06194-chung-tu-ban-hang`.
3. Thư mục đích mặc định `docs/html/<PYC>/` **ở gốc repo** (không phải trong `pmkt-docs/`).
   Chưa có thì `mkdir -p`. User chỉ định khác thì theo user.
4. File đích đã tồn tại → hỏi ghi đè hay tạo bản mới; **không âm thầm ghi đè**.
5. Đã có Artifact cũ của epic này (user đưa URL hoặc `action: "list"` thấy) → publish kèm `url` để
   giữ nguyên link, **không tạo artifact thứ hai**.

---

## 1. Đọc tài liệu — đọc hết trước khi vẽ

Đọc theo đúng thứ tự này, không bỏ bước:

| Bước | File | Rút ra |
|---|---|---|
| 1 | `1.functions-breakdown.md` | Phạm vi epic · danh sách chức năng con · mã `PMKT-U-*` |
| 2 | `2.usecases.puml` · `3.crud-matrix.puml` | Danh sách UC · entity nào bị C/R/U/D ở UC nào |
| 3 | `4.usecases/*/UC_*.md` | Luồng chính · luồng phụ · ngoại lệ · tiền/hậu điều kiện · quyền |
| 4 | `4.usecases/*/AD_*.puml` | **Xương sống của sơ đồ** — nhánh quyết định và thứ tự kiểm |
| 5 | `5.screens/SCR_*.md` | Toàn bộ `BR*` — điều kiện hiện nút, công thức, ràng buộc chặn |
| 6 | `6.messages.md` | Mã `MSG_*` gắn vào từng nhánh chặn |
| 7 | `Matrix/**` (nếu có) | Ma trận ẩn/hiện trường theo chế độ màn hình |

Màn hình lớn (>1000 dòng) thì `grep -n '^#\{1,4\} '` lấy mục lục trước, rồi đọc từng khối BR — không
đọc tràn cả file rồi mất ngữ cảnh.

**Bắt buộc đối chiếu** BR cho phạm vi vừa đọc — tra bảng ở `CLAUDE.md` rồi chạy `./docs/rules/br.sh <số BR>`, KHÔNG đọc cả file: BR chung
(BR1 phân trang · BR12 trạng thái · BR25 phân quyền · BR36 ghi sổ …) vẫn áp dù epic không nhắc lại.

---

## 2. Lập dàn ý section — một luồng, một section

Sắp theo **vòng đời chứng từ / bản ghi**, không theo thứ tự file:

```
00  Tổng quan      — bản đồ trạng thái + bảng trạng thái dẫn xuất
01  Xem danh sách  — màn điều phối, luật gác nút
02  Thêm mới       — tách 2 sơ đồ: chuỗi nhập liệu và chuỗi lưu
03  Quan hệ dữ liệu— bản ghi liên kết sinh ra, ai ghi sổ cái gì
04..n Nghiệp vụ đặc thù (chiết khấu, phân bổ, quy đổi…)
n+1 Chỉnh sửa · Ghi sổ · Bỏ ghi sổ · Xóa · Xem chi tiết
n+2 Trường dẫn xuất / counter
n+3 Bảng tra: điều kiện chặn ↔ mã MSG · ma trận quyền
```

Mỗi section gồm: `<h2>` + 1 câu lede + `<figure>` sơ đồ + `<figcaption>` **nêu đúng một khẳng định**
+ bảng tra hoặc callout nếu có ràng buộc dễ sai.

**Sơ đồ phải vẽ cơ chế, không vẽ tên gọi.** Nhánh quyết định lấy nguyên từ AD; nhãn cạnh ghi điều
kiện thật (`Chưa ghi sổ`, `Tồn kho đủ?`), không để mũi tên trống nghĩa.

---

## 3. Viết HTML

Theo `references/khung-html.md`. Tóm tắt ràng buộc cứng:

- **Một file, tự chứa.** CSS inline, không script ngoài. Sơ đồ dùng `<pre class="mermaid">` —
  Artifact render mermaid sẵn, **không** nhúng thư viện.
- **Font phải có subset `vietnamese`** — Bitter · IBM Plex Sans · IBM Plex Mono · Be Vietnam Pro ·
  Lora · Roboto Slab. Font chỉ có `latin-ext` sẽ rơi fallback ở mọi chữ có dấu.
- **Theme:** khai đủ 3 nhánh `:root` / `@media (prefers-color-scheme: dark)` + `:not([data-theme="light"])`
  / `:root[data-theme="dark"]`. Riêng khung chứa sơ đồ (`.plate`) **luôn nền sáng ở cả hai theme**
  vì màu mermaid cố định cho nền sáng.
- **Không hardcode màu ngoài token.** Ngoại lệ duy nhất: chuỗi `themeVariables` của mermaid.
- Mọi bảng và mọi `.plate` bọc `overflow-x:auto`; thân trang **không được** cuộn ngang.
- Tiêu đề `<title>` là **tên**, 2–4 từ, không kèm phần giải thích sau dấu gạch.

---

## 4. Verify — bắt buộc, không được bỏ

Theo `references/kiem-tra.md`. Không publish khi chưa qua đủ 4 cổng:

| Cổng | Đạt khi |
|---|---|
| 1 Cân bằng thẻ | mọi `section` · `figure` · `table` · `div` · `pre` đóng đủ |
| 2 Parse mermaid | `mermaid.parse` từng block, mảng lỗi **rỗng** |
| 3 Bề rộng sơ đồ | mỗi SVG ≤ ~1800px; vượt thì đổi hướng TD↔LR hoặc tách sơ đồ |
| 4 Đo lẹm chữ | script đếm nhãn tràn `foreignObject` trả về **`clip: 0`** — đo bằng số, không nhìn ảnh |
| 5 Chụp màn hình | đọc được ở cả light và dark, màu ô đúng vai trò |
| 6 Xuất standalone | bản `docs/` có `<meta charset>`, đủ số `<svg>`, còn 0 `<pre>` chưa render |
| 7 Trang tổng hợp | thẻ mới đã thêm, mọi link nội bộ resolve (mục 5) |

---

## 5. Cập nhật trang tổng hợp — bắt buộc, không được bỏ

`docs/html/tong_hop.html` là trang tra cứu chung cho mọi epic đã sinh. **Publish xong là phải thêm
thẻ**, nếu không trang mới nằm mồ côi trong thư mục con.

1. Đọc `docs/html/tong_hop.html`, tìm nhóm `<h2>` theo **phân hệ** của epic (Bán hàng · Tổng hợp ·
   Kho · Mua hàng…).
2. Nhóm chưa có → tạo `<h2>` + `<p class="sub">` một câu định vị nhóm + `<div class="grid">` mới,
   đặt sau nhóm cuối cùng và **trước** khối `.note` "Cách dùng".
3. Chèn một `<article class="card">` vào cuối `.grid` của nhóm đó, đúng khuôn:

```html
  <article class="card">
    <span class="code">PMKT-E-xxxxx</span>
    <h3><a href="<PYC>/<slug>-flow.html">Tên epic ngắn</a></h3>
    <p>Một hoặc hai câu nêu ĐẶC THÙ của epic — cái khiến nó khác các epic cùng phân hệ,
       không phải mô tả lại tên chức năng.</p>
    <div class="meta">
      <span class="tag">N mục</span><span class="tag">N sơ đồ</span>
      <span class="tag">N UC · N màn</span><span class="tag">phạm vi BR / ma trận</span>
    </div>
    <div class="links">
      <a href="<PYC>/<slug>-flow.html">Mở trang →</a>
      <a href="URL Artifact">Artifact ↗</a>
    </div>
  </article>
```

4. Cập nhật 3 số ở khối `.stats` trên đầu trang: **Epic** (đếm `<article`), **Sơ đồ** (tổng số sơ đồ
   của tất cả epic), **Cập nhật** (ngày hôm nay).
5. Kiểm lại — mọi link nội bộ phải resolve. Script kiểm nằm ở `references/kiem-tra.md` (Cổng 7).

> Trang tổng hợp là file **standalone** (có `<!doctype>` + `<meta charset>`) và **không có sơ đồ
> mermaid** — không publish nó lên Artifact, không áp quy trình 6 cổng của trang epic cho nó.

---

## Báo cáo khi xong

1. URL Artifact + đường dẫn file `.html` + xác nhận đã thêm thẻ vào `tong_hop.html`.
2. Số section · số sơ đồ · nguồn đã đọc (bao nhiêu UC / AD / màn hình / BR).
3. Luồng nào tài liệu BA **chưa quy định rõ** nên chưa vẽ được — nêu tên, không tự bịa nhánh.
4. BR chung đã áp dụng / chưa đạt (theo các BR đã trích qua `./docs/rules/br.sh`).
