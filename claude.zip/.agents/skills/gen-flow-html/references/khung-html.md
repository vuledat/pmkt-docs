# Khung trang HTML + 6 bẫy kỹ thuật

## 1. Sáu bẫy — đọc trước khi viết, mỗi bẫy đều đã làm hỏng trang thật

### Bẫy 1 — chữ trong nhãn bị lẹm mất đuôi (lỗi hay gặp nhất)

Triệu chứng: `Ghi sổ — sinh bút toán BR2` (mất số 0), `xóa sạch bút toá` (mất chữ n). Cắt ở **nhãn
cạnh** nhiều hơn nhãn node, mỗi chỗ mất 1–2 ký tự.

**Nguyên nhân:** mermaid dựng sơ đồ trong một **container tạm gắn ở `<body>`**, đo bề rộng từng nhãn
ở đó rồi mới chuyển SVG đã hoàn thiện vào `pre.mermaid`. Nhãn nằm trong `<foreignObject>` — mà
`<foreignObject>` **cắt** phần tràn. Nên nếu CSS font khai **scope vào `.plate .mermaid`** thì lúc đo
nó chưa áp, lúc vẽ mới áp: hai font khác nhau → hộp hẹp hơn chữ → cắt.

Sai lầm nối tiếp: hạ `font-size` xuống 13.4px cho chữ "vừa hộp". Nó chỉ giấu bớt triệu chứng, vẫn còn
hơn 200 nhãn lẹm và làm chữ nhỏ đi vô cớ.

**Sửa đúng — khai font ở phạm vi TOÀN TRANG, không scope, để lúc đo và lúc vẽ dùng chung một font:**

```css
.mermaid,.nodeLabel,.edgeLabel,.cluster-label,.label,
foreignObject div,foreignObject span,foreignObject p{
  font-family:"Helvetica Neue",Helvetica,Arial,sans-serif !important}
.nodeLabel,.edgeLabel,.cluster-label,.label,foreignObject div{
  font-size:14px !important; line-height:1.4 !important}
/* lưới an toàn: sai số đo vài px cũng không cắt chữ, nhãn chỉ tràn nhẹ khỏi khung */
foreignObject{overflow:visible !important}
```

`font-size` phải **đúng bằng** `themeVariables.fontSize` khai trong chuỗi init. Không đặt lệch.

Kiểm bằng số, không kiểm bằng cảm giác — đo `div` con của mỗi `foreignObject` so với chính
`foreignObject`, **không** đo `scrollWidth` của `div` (div co theo nội dung nên `scrollWidth` luôn
bằng `clientWidth`, chỉ số này **không phát hiện được lỗi**):

```js
(()=>{let tot=0,clip=0,max=0;document.querySelectorAll('pre.mermaid foreignObject').forEach(fo=>{
  const d=fo.firstElementChild; if(!d) return; tot++;
  const o=d.getBoundingClientRect().width-fo.getBoundingClientRect().width;
  if(o>0.5){clip++;max=Math.max(max,o);} });
 return JSON.stringify({tot,clip,max:+max.toFixed(1)});})()
```

`clip` phải bằng **0**. Còn số dương là còn chữ bị lẹm.

### Bẫy 2 — dùng webfont cho nhãn sơ đồ

Webfont tải xong **sau** khi mermaid đã đo → chữ đổi bề rộng → lẹm y hệt bẫy 1. Nhãn sơ đồ luôn dùng
**font hệ thống** (`Helvetica Neue, Helvetica, Arial`). Webfont chỉ dùng cho phần text của trang.

Cùng lý do: `<pre>` mặc định là `monospace`, nếu không khai đè thì nhãn kế thừa monospace trong khi
mermaid đo bằng font khác. Kiểm nhanh:

```js
getComputedStyle(document.querySelector('pre.mermaid .nodeLabel')).fontFamily
```

Trả về `monospace` là hỏng — phải ra đúng stack Helvetica.

### Bẫy 3 — sơ đồ bị co nhỏ đến mức không đọc được

Mặc định mermaid xuất `width="100%"` + `max-width`, nên sơ đồ rộng 2300px bị ép vào cột 800px →
chữ còn ~5px. CSS `max-width:none` **không cứu được** vì `width:100%` vẫn ăn theo container.

Sửa bằng chính config của mermaid, đặt ở đầu **mọi** block:

```
%%{init:{"flowchart":{"useMaxWidth":false},"theme":"base","themeVariables":{"primaryColor":"#ffffff","primaryTextColor":"#16202b","primaryBorderColor":"#2f6f8f","lineColor":"#6b7683","fontFamily":"Helvetica Neue, Helvetica, Arial, sans-serif","fontSize":"14px"}}}%%
```

Kèm `.plate{overflow-x:auto}` để sơ đồ rộng cuộn ngang trong khung, thân trang vẫn không cuộn ngang.

### Bẫy 4 — chọn sai hướng TD/LR làm sơ đồ phình ngang

| Hình dạng luồng | Hướng đúng |
|---|---|
| Nhiều nhánh song song, chuỗi nông (màn điều phối, danh sách nút) | `LR` — nhánh xếp dọc |
| Chuỗi sâu, nhãn dài (chuỗi validate, chuỗi ghi dữ liệu) | `TD` |

`LR` **không** phải lúc nào cũng hẹp hơn: bề rộng `LR` = độ sâu chuỗi × bề rộng nhãn. Luôn **đo lại**
sau khi đổi hướng, giữ phương án nhỏ hơn.

### Bẫy 5 — `stateDiagram-v2` cắt nhãn nhiều dòng

Nhãn composite của `stateDiagram-v2` hay bị cắt. Vẽ bản đồ trạng thái bằng `flowchart LR` với nhãn
`<b>TÊN TRẠNG THÁI</b><br/>…` cho chắc.

### Bẫy 6 — ký tự phá cú pháp trong nhãn

- Nhãn chứa `(`, `)`, `,`, `:` → phải bọc nháy kép: `A["Ghi sổ (BR20)"]`.
- Không dùng `<` `>` trong nhãn; dùng `≤ ≥ →` thay thế.
- Xuống dòng bằng `<br/>`, không xuống dòng thật.
- Nhãn cạnh dài cũng bọc nháy: `A -- "Tồn kho đủ?" --> B`.

---

## 2. Design token — chọn theo chủ đề, không bê nguyên

Bảng dưới là **ví dụ đã dùng cho epic kế toán** (mực xanh + triện đỏ + giấy sổ). Epic khác thì đổi
hue cho hợp chủ đề, giữ nguyên **cấu trúc** token và quy tắc 3 nhánh theme.

```css
:root{
  --ink:#16202b; --ink-soft:#4a5765; --ink-faint:#7c8896;
  --bg:#f4f6f8; --surface:#ffffff; --rule:#dde3e9; --rule-soft:#eaeef2;
  --blue:#2f6f8f; --blue-soft:#e8f0f4;      /* cấu trúc */
  --seal:#b23a2e; --seal-soft:#fbeceb;      /* chặn / lỗi */
  --ok:#2e7d5b;  --ok-soft:#e8f4ee;         /* thành công */
  --warn:#a9761f;--warn-soft:#fbf2e2;       /* cảnh báo */
  --plate:#faf8f3; --plate-rule:#e3ded2;    /* nền sơ đồ — sáng ở CẢ HAI theme */
}
@media (prefers-color-scheme: dark){
  :root:not([data-theme="light"]){ /* … đổi ink/bg/surface/rule; --plate chỉ dịu đi: #e7e3da … */ }
}
:root[data-theme="dark"]{ /* lặp lại đúng bộ trên để nút chuyển theme thắng */ }
```

Ba vai trò màu trong sơ đồ **phải trùng** với token của trang, khai bằng `classDef` cuối mỗi block:

```
classDef err  fill:#fbeceb,stroke:#b23a2e,color:#7a2318;
classDef ok   fill:#e8f4ee,stroke:#2e7d5b,color:#1c4c38;
classDef warn fill:#fbf2e2,stroke:#a9761f,color:#6d4a12;
```

---

## 3. Bố cục

- `grid-template-columns:236px minmax(0,1fr)` — rail mục lục `position:sticky` + cột nội dung; dưới
  980px gộp một cột.
- Chữ chạy ~72ch. Sơ đồ và bảng được rộng hết cột.
- Font: slab serif cho `h1/h2` (Bitter), sans cho body (IBM Plex Sans), mono cho tên trường và mã
  `MSG_*`/`BR*` (IBM Plex Mono) — cả ba đều có subset `vietnamese`.
- Chip mã hoá: `.c-msg` (đỏ, mã message) · `.c-br` (xanh, mã BR) · `.c-ok` / `.c-warn` / `.c-perm`.

## 4. Bộ khung tối thiểu của một section

```html
<section id="s6">
  <span class="snum">06 — UC_XXX_GhiSo</span>
  <h2>Tiêu đề nêu bản chất, không phải tên chức năng</h2>
  <p class="lede">Một câu chốt điều quan trọng nhất của luồng.</p>
  <figure>
    <div class="plate">
<pre class="mermaid">
%%{init:{…}}%%
flowchart TD
    …
</pre>
    </div>
    <figcaption><b>Một khẳng định.</b> Điều sơ đồ chứng minh, không mô tả lại các ô.</figcaption>
  </figure>
  <div class="tw"><table>…</table></div>
</section>
```
