# Đặc tả API xuất ra `docs/json/` — `/gen-be` bước 12 (BẮT BUỘC)

Mỗi lần `/gen-be` chạy xong phải để lại **một file JSON import thẳng vào Postman được**:

```
docs/json/<slug>.postman_collection.json
```

`<slug>` = slug của epic, ví dụ `PMKT-E-07528-khoa-so` → `docs/json/PMKT-E-07528-khoa-so.postman_collection.json`.

Mẫu tham chiếu có sẵn trong repo: `docs/json/PMKT-chung-tu-mua-hang.postman_collection.json` — mở ra
xem trước khi sinh file mới, giữ đúng phong cách đó.

## Cách lấy đặc tả — ưu tiên máy sinh, chỉ viết tay khi không chạy được app

`cell-app` đã có `springdoc-openapi-starter-webmvc-ui` (`build.gradle.kts`) và bật sẵn:
`/v3/api-docs` (JSON) · `/swagger-ui.html`.

**Cách 1 (ưu tiên) — lấy từ app đang chạy.** Chạy `cell-app` qua IntelliJ
(`mcp__idea__get_run_configurations` → `mcp__idea__execute_run_configuration`, **không Docker**), rồi:

```bash
curl -s http://localhost:8081/v3/api-docs > /tmp/openapi.json
```

Từ file đó lọc **đúng các path của module vừa làm** rồi dựng collection. Không nhét cả API của repo
vào một collection.

**Cách 2 — app không chạy được** (thiếu DB, thiếu env, BE chưa boot): dựng collection **thẳng từ hợp
đồng API trong plan** (`NN-<chuc-nang>.md` mục "Hợp đồng API"), và **ghi rõ trong báo cáo** là file
chưa được đối chiếu với app đang chạy.

## Khung file bắt buộc — Postman Collection v2.1.0

```json
{
  "info": {
    "name": "PMKT — <Tên nghiệp vụ> (PMKT-E-xxxxx)",
    "description": "API module <...> — `<base path>` (epic PMKT-E-xxxxx).\n\nGIAI ĐOẠN HIỆN TẠI: ...\n\nCÁCH DÙNG\n1. ...",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "auth": { "type": "bearer", "bearer": [{ "key": "token", "value": "{{token}}", "type": "string" }] },
  "variable": [
    { "key": "baseUrl", "value": "http://localhost:8081" },
    { "key": "identityUrl", "value": "http://localhost:8080" },
    { "key": "username", "value": "" },
    { "key": "password", "value": "" },
    { "key": "token", "value": "" }
  ],
  "item": [ ... ]
}
```

**Luật nội dung:**

1. **Nhóm `item` đánh số theo luồng nghiệp vụ**, nhóm đầu luôn là `0. Auth` (request lấy token, có
   script lưu vào biến `{{token}}`). Ví dụ nhóm tiếp theo: `1. Danh sách & metadata` ·
   `2. Chi tiết` · `3. <nghiệp vụ riêng>` · `4. Excel` · `5. Ca kiểm thử kỳ vọng lỗi`.
2. **Mỗi request có `description`** nói *vì sao* gọi và kỳ vọng gì — trích BR/quyết định `D…` của plan,
   không mô tả lại chữ ký JSON.
3. **Body mẫu phải chạy được thật**, không phải `"string"` do springdoc sinh: dùng đúng dữ liệu mẫu
   trong plan / `6.messages.md`.
4. **Id động đi qua `variable`** (`{{ctuId}}`…), không hardcode UUID vào URL.
5. **Nhóm "Ca kiểm thử kỳ vọng lỗi" là bắt buộc** khi có validation nghiệp vụ: mỗi mã lỗi trong
   `6.messages.md` nên có ít nhất một request minh hoạ.
6. Endpoint **chưa hỗ trợ** (kế thừa từ base nhưng chưa làm) vẫn giữ trong collection, ghi rõ trong
   `description` là trả lỗi gì và use case nào phụ trách.

## Kèm theo (tuỳ chọn nhưng nên có)

Lấy được từ app đang chạy thì lưu thêm bản OpenAPI thô đã lọc theo module:
`docs/json/<slug>.openapi.json`. Postman import được cả hai, nhưng **file bắt buộc vẫn là
`.postman_collection.json`** vì nó mới mang biến môi trường, auth và body mẫu chạy được.

## Nghiệm thu file JSON

```bash
python3 -c "import json;d=json.load(open('docs/json/<slug>.postman_collection.json'));print(d['info']['name'], len(d['item']),'nhóm')"
```

JSON không parse được = chưa xong. Báo cáo phải nêu **đường dẫn file** + **số nhóm/số request** +
lấy bằng cách 1 hay cách 2.
