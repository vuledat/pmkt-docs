# Mẫu tài liệu đầu ra — `/plan-be` bước 3–6

## Cấu trúc thư mục đầu ra

```
docs/doing/<slug>-api/
├── 00-ke-hoach-tong.md          ← file gốc, bắt buộc
├── 01-<chuc-nang-1>.md          ← một file / một chức năng trong 1.function-breakdown.md
├── 02-<chuc-nang-2>.md
└── NN-thiet-ke-db.md            ← bắt buộc nếu có chạm DB
```

Tên file con: 2 chữ số + kebab-case tiếng Việt không dấu, bám chức năng của BA
(`01-xem-danh-sach-thiet-lap.md`, `07-job-tu-dong-khoa-so.md`). Mỗi file con **một chức năng** —
đừng gộp 2 UC khác luồng, cũng đừng tách một UC thành 3 file.

## `00-ke-hoach-tong.md` — bám mục lục `docs/rules/_bieu-mau-plan-api.md`

| § | Nội dung | Ghi chú bắt buộc |
|---|---|---|
| header | Trạng thái · ngày · người review · bảng UC/màn/tài liệu nguồn/module BE/bảng DB | |
| 0 | Quyết định đã chốt `D1…Dn` | quyết định + **hệ quả cụ thể lên code**; kèm "vì sao KHÔNG chọn phương án kia" |
| 1 | Phạm vi — trong / **NGOÀI** phạm vi | ngoài phạm vi nêu **đích danh mã UC**, nói rõ endpoint kế thừa từ base trả gì |
| 2 | Hiện trạng đã khảo sát: code · DB · base có sẵn | bảng "Cần / Đã có ở base / `file:dòng`" |
| 3 | Kiến trúc: phân tầng · lựa chọn + lý do · cây thư mục module | cây phải đúng `<module>/api\|internal/` của Modulith |
| 4 | Danh mục API mục tiêu `A1…An` | bảng: method · path · UC · file con phụ trách |
| 5 | Ma trận UC → endpoint → tài liệu | mọi UC trong `4.usecases/` xuất hiện đúng 1 lần |
| 6 | Luồng tổng thể | sequence/flow chữ hoặc mermaid |
| 7 | Migration dự kiến `V<yyyyMMddHHmmss>` | version = timestamp lúc tạo file (`date +V%Y%m%d%H%M%S`), KHÔNG phải max + 1 |
| 8 | Thứ tự thực hiện | chia bước, nêu phụ thuộc giữa các file con |
| 9 | Rủi ro kỹ thuật `R1…Rn` | kèm cách giảm thiểu |
| 10 | Quyền — mã quyền, đã seed chưa | chưa seed thì nói rõ phải seed trước khi test (BR25) |
| 11 | Mã thông báo | **nguyên văn** từ `6.messages.md`, không tự diễn đạt lại |
| 12 | ⚠️ Điểm cần BA xác nhận `Q1…Qn` | mâu thuẫn tài liệu phải trích bằng chứng **cả hai phía** |
| 13 | Điều kiện nghiệm thu — BA xác nhận / Dev xác nhận | |
| 14 | Quy chuẩn nghiệp vụ (BR) áp dụng | liệt kê BR + áp ở đâu |
| 15 | Tài liệu tham chiếu | |

Mục không áp dụng → ghi `Không áp dụng — <lý do>`, **không xoá tiêu đề**.
Đánh số dùng chéo: `D1…` quyết định · `F1…` chức năng · `A1…` endpoint · `R1…` rủi ro · `Q1…` câu hỏi
BA. Trỏ chéo dạng "xem §12-Q5", "theo quyết định D2".

## Mỗi file con `NN-<chuc-nang>.md` — chỗ user cần chi tiết nhất

1. **Header** — mã `F0N`, tên chức năng, UC nguồn, màn hình nguồn, endpoint phụ trách.
2. **Quyết định riêng của chức năng** (nếu có) — trỏ về `D…` ở file gốc.
3. **Hợp đồng API** — mỗi endpoint: method + path + quyền · request JSON mẫu **đầy đủ** + bảng field
   (tên · kiểu · bắt buộc · ràng buộc · nguồn BA) · response thành công bọc `ApiResponse<T>` ·
   bảng mã lỗi ↔ HTTP status ↔ mã message trong `6.messages.md`.
4. **Ánh xạ cột BA ↔ DB ↔ DTO** — bảng 3 cột; cột dẫn xuất/tính toán thì nêu công thức.
5. **Validation — ma trận đầy đủ** — mỗi luật: điều kiện · thời điểm kiểm · thông báo · BR nguồn.
6. **Luồng xử lý** — bước đánh số, nêu rõ chỗ gọi base (`ChungTuTemplate`, `GhiSoApi`,
   `BaseCrudService`), chỗ override, chỗ viết mới. Có sơ đồ nếu luồng rẽ nhánh.
7. **Tương tranh & transaction** — ranh giới `@Transactional`, khoá, idempotency (nếu ghi).
8. **Phân trang · sắp xếp · lọc · dòng tổng** (màn danh sách) — BR1, BR2, BR11, BR31.
9. **Kiểm thử** — case unit (`@Tag("unit")`) + case tích hợp, mỗi case: input → kỳ vọng.
10. **BR đã áp dụng** — mã BR + áp ở bước nào.

Chức năng đặc thù thì thêm mục riêng (job tự động → lịch chạy, retry, log; popup chọn nguồn → nguồn
dữ liệu và điều kiện lọc).

## `NN-thiet-ke-db.md`

1. Hiện trạng bảng (trích migration hiện có, ghi rõ số cột)
2. Cột thêm mới / sửa trên bảng đã có — bảng: cột · kiểu · null · default · lý do
3. Bảng mới — full định nghĩa cột
4. Ràng buộc · index · khoá ngoại (kèm lý do từng index)
5. Migration `V<yyyyMMddHHmmss>` — SQL đầy đủ, chạy được
6. Kiểm dữ liệu trước khi chạy migration + backfill + tương thích ngược
7. Ánh xạ Entity ↔ bảng
8. ERD (mermaid)
9. Kiểm thử dữ liệu
10. Tóm tắt cho người ký duyệt

Bắt buộc theo BR7 (precision & làm tròn) · BR20 (số chứng từ & mã danh mục) · BR28 (multi-tenant) ·
BR29 (chính sách xoá) · BR46 (trường hệ thống bắt buộc).
